import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InnovatorMartianTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getParent() {
    }

    @Test
    void setParent() {
    }

    @Test
    void setParent1() {
    }

    @Test
    void getChildren() {
    }

    @Test
    void getDescadant() {
    }

    @Test
    void setDescadant() {
    }

    @Test
    void updateAncestors() {
    }

    @Test
    void getGeneticCode() {
    }

    @Test
    void setGeneticCode() {
    }

    @Test
    void hasChildWithValue() {
    }

    @Test
    void hasDescadantWithValue() {
    }

    @Test
    void hasAncestorsWithValue() {
    }

    @Test
    void addChild() {
    }

    @Test
    void addChild1() {
    }

    @Test
    void removeChild() {
    }

    @Test
    void testToString() {
    }
}