import java.util.ArrayList;

public abstract class Martian<T> {
    public Martian(){
    }

    public abstract Martian<T> getParent();
    public abstract ArrayList<Martian<T>> getChildren();
    public abstract ArrayList<Martian<T>> getDescadant();
    public abstract T getGeneticCode();
    public abstract boolean hasChildWithValue(T value);
    public abstract boolean hasDescadantWithValue(T value);
}
