import java.util.ArrayList;

public class InnovatorMartian<T> extends Martian<T> {
    private InnovatorMartian<T> parent;
    private ArrayList<Martian<T>> children;
    private ArrayList<Martian<T>> descents;
    private ArrayList<Martian<T>> ancestors;
    private T geneticCode;
    //private String descents_str;

    public InnovatorMartian( T geneticCode, InnovatorMartian<T> parent) {
        this.parent = parent;
        this.children =  new ArrayList<Martian<T>>();
        this.geneticCode = geneticCode;
        descents = initializeDescents(this);
        ancestors = initializeAncestors(this);
        ancestors.remove(this);
    }

    private ArrayList<Martian<T>> initializeDescents(Martian<T> cur_martian) {
        ArrayList<Martian<T>> result = new ArrayList<>();
        ArrayList<Martian<T>> children = cur_martian.getChildren();
        for (Martian<T> child : children) {
            result.addAll(initializeDescents(child));
        }
        result.add(cur_martian);
        return result;
    }

    private ArrayList<Martian<T>> initializeAncestors(Martian<T> cur_martian) {
        ArrayList<Martian<T>> result = new ArrayList<>();
        Martian<T> parent = cur_martian.getParent();
        if (parent != null) {
            result.addAll(initializeAncestors(parent));
        }
        result.add(cur_martian);
        return result;
    }

    @Override
    public Martian<T> getParent() {
        if (parent == null) {
            return null;
        }
        return parent;
    }

    public void setParent(InnovatorMartian<T> new_parent) {
        T new_par_geneticCode = new_parent.getGeneticCode();
        if (parent == null) {
            return;
        }
        if (new_par_geneticCode == geneticCode) {
            throw new IllegalArgumentException("You can not add yourselves to your parent!");
        }
        if (hasAncestorsWithValue(new_par_geneticCode)) {
            throw new IllegalArgumentException(String.format("Error with setting Parent! " +
                    "Martian with <%s>g/c was found in Ancestors of <%s>g/c martian", new_par_geneticCode, geneticCode));
        }
        if (hasDescadantWithValue(new_par_geneticCode)) {
            throw new IllegalArgumentException(String.format("Error with setting Parent! " +
                    "Martian with <%s>g/c was found in Descendants of <%s>g/c martian", new_par_geneticCode, geneticCode));
        }
        parent = new_parent;

        ancestors = initializeAncestors(this); //Update ancestors
        ancestors.remove(this);
        parent.addChild1(this);
        parent.setDescadant(parent.getChildren()); //Update descents of new parent
    }
    public void setParent1(InnovatorMartian<T> new_parent) {
        T new_par_geneticCode = new_parent.getGeneticCode();

        parent = new_parent;

        ancestors = initializeAncestors(this); //Update ancestors
        ancestors.remove(this);
        //parent.addChild1(this);
        parent.setDescadant(parent.getChildren()); //Update descents of new parent
    }
    @Override
    public ArrayList<Martian<T>> getChildren() {
        return children;
    }

    @Override
    public ArrayList<Martian<T>> getDescadant() {
        return descents;
    }

    public ArrayList<Martian<T>> setDescadant(ArrayList<Martian<T>> children) {
        this.children = children;
        //descents = children;

        descents = initializeDescents(this);
        descents = children;
        return descents;
    }

    public void updateAncestors() {
        ancestors = initializeAncestors(this);
        ancestors.remove(this);
    }

    @Override
    public T getGeneticCode() {

        return geneticCode;
    }

    /**
     *Setter that sets up a new genetic code.
     * @param new_code new genetic code.
     */
    public void setGeneticCode(T new_code) {
        if (new_code == null) {
            throw new NullPointerException();
        }
        if (hasAncestorsWithValue(new_code)) {
            throw new IllegalArgumentException(String.format("Error with setting GeneticCode! " +
                    "Martian with <%s>g/c was found in Ancestors of <%s>g/c martian", new_code, geneticCode));
        }
        if (hasDescadantWithValue(new_code)) {
            throw new IllegalArgumentException(String.format("Error with setting GeneticCode! " +
                    "Martian with <%s>g/c was found in Descadants of <%s>g/c martian", new_code, geneticCode));
        }
        geneticCode = new_code;
    }

    @Override
    public boolean hasChildWithValue(T value) {
        for (Martian<T> child : children) {
            if (child.getGeneticCode() == value) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean hasDescadantWithValue(T value) {
        for (Martian<T> descent : descents) {
            if (descent.getGeneticCode() == value) {
                return true;
            }
        }
        return false;
    }

    public boolean hasAncestorsWithValue(T value) {
        for (Martian<T> ancestor : ancestors) {
            if (ancestor.getGeneticCode() == value) {
                return true;
            }
        }
        return false;
    }

    public boolean addChild(InnovatorMartian<T> new_child) {
        T new_child_geneticCode = new_child.getGeneticCode();
        if (hasChildWithValue(new_child_geneticCode) ||
                hasAncestorsWithValue(new_child_geneticCode) || hasDescadantWithValue(new_child_geneticCode)) {
            return false;
        }
        if (new_child.getParent() != null) {
            ((InnovatorMartian) new_child.getParent()).removeChild(new_child);
        }
        children.add(new_child);
        new_child.setParent1(this);
        return true;
    }
    public boolean addChild1(InnovatorMartian<T> new_child) {
        T geneticCode1 = new_child.getGeneticCode();
        if (hasChildWithValue(geneticCode1) ||
                hasAncestorsWithValue(geneticCode1) || hasDescadantWithValue(geneticCode1)) {
            return false;
        }
        if (new_child.getParent() != null) {
            ((InnovatorMartian) new_child.getParent()).removeChild(new_child);
        }
        children.add(new_child);
        //new_child.setParent(this);
        return true;
    }

    public boolean removeChild(InnovatorMartian<T> child) {
        if (hasChildWithValue(child.getGeneticCode())) {
            children.remove(child);
            descents = initializeDescents(this);
            child.setParent(null);
            child.updateAncestors();
            return true;
        }
        return false;
    }
    public String toString(){
        return "Inovative Martian (" + geneticCode.getClass().getSimpleName() + ":" + geneticCode.toString() + ")";
    }
}
