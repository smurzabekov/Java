import java.util.ArrayList;

public class ConservativeMartian<T> extends Martian<T> {
    private final Martian<T> parent;
    private final ArrayList<Martian<T>> children;
    private final ArrayList<Martian<T>> descadants;
    private final T geneticCode;

    public ConservativeMartian(Martian<T> parent, ArrayList<Martian<T>> children, T geneticCode){
        this.parent = parent;
        this.children = children;
        this.geneticCode = geneticCode;
        descadants = initializeDescadants(this);
    }

    /**
     * Getter, returns parent. If it's empty, returns null.
     * @return If it's empty, returns null.
     */
    @Override
    public Martian<T> getParent(){
        return parent;
    }

    /**
     * Getter, returns children collection. If it's empty, returns null.
     * @return  If it's empty, returns null.
     */
    @Override
    public ArrayList<Martian<T>> getChildren(){
        return children;
    }


    private ArrayList<Martian<T>> initializeDescadants(Martian<T> cur_martian){
        ArrayList<Martian<T>> result = new ArrayList<>();
        ArrayList<Martian<T>> children = cur_martian.getChildren();
        for (Martian<T> child : children) result.addAll(initializeDescadants(child));
        result.add(cur_martian);
        return result;
    }

    /**
     * Getter, returns all descendants.
     * @return all descendants.
     */
    @Override
    public ArrayList<Martian<T>> getDescadant(){
        return descadants;
    }

    /**
     * Getter, returns generic code of martian.
     * @return returns generic code of martian
     */
    @Override
    public T getGeneticCode(){
        return geneticCode;
    }

    /**
     * Getter which returns is that value child in children or not by genetic code.
     * @param value returns is that value child in children or not by genetic code.
     * @return returns is that value child in children or not by genetic code
     */
    @Override
    public boolean hasChildWithValue(T value){
        for (Martian<T> child : children) {
            if (child.getGeneticCode() == value) {
                return true;
            }
        }
        return false;
    }

    /**
     * Getter which returns is that value descendance in descendances or not by genetic code.
     * @param value descendance
     * @return bool
     */
    @Override
    public boolean hasDescadantWithValue(T value){
        for (Martian<T> descadant : descadants) {
            if (descadant.getGeneticCode() == value) {
                return true;
            }
        }
        return false;
    }


}
