//import java.util.ArrayList;

public class MartianTree<T> {
    private final Martian<T> head_martian;

    public MartianTree(Martian<T> head_martian){
        this.head_martian = head_martian;
    }

    /**
     * Метод повтора пустой строки
     * @param count k
     * @param with k
     * @return k
     */
    private String repeat(int count, String with) {
        return new String(new char[count]).replace("\0", with);
    }

    /**
     * Метод повтора пустой строки
     * @param count k
     * @return k
     */
    private String repeat(int count) {
        return repeat(count, " ");
    }

    public void ToString(Martian<T> martian, int count) {
        System.out.println(repeat(count) + martian.toString());
        if (martian.getChildren().size() == 0) return;
        for (int i = 0; i < martian.getChildren().size(); i++) {
            ToString(martian.getChildren().get(i), count+4);
        }
    }
}
