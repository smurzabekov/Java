package test.ru.hse.murzabekov.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import ru.hse.murzabekov.db.ApacheDerbyDB;
import ru.hse.murzabekov.db.Database;
import ru.hse.murzabekov.db.OperationsDB;
import ru.hse.murzabekov.model.Contact;
import ru.hse.murzabekov.utils.Utils;

public class FakeOperations implements OperationsDB {
    private final Database db;

    public FakeOperations(final Database db) {
        this.db = db;
    }

    @Override
    public Collection<Contact> list() throws SQLException {
        final List<Contact> contacts = new ArrayList<>();
        ResultSet resSet = db.getConnection().createStatement()
            .executeQuery(String.format("SELECT * FROM %s ", ApacheDerbyDB.TABLE));
        Utils.addContactsTo(resSet, contacts);
        return contacts;
    }

    @Override
    public void add(final Contact contact) throws SQLException {
        db.getConnection().createStatement()
            .executeUpdate(
                String.format("INSERT INTO %s ", ApacheDerbyDB.TABLE)
                    + " (SURNAME, NAME, PATRONYMIC, MOBILE_PHONE, HOME_PHONE, ADDRESS, BIRTH, NOTES) VALUES ( "
                    + "'" + contact.getSurname() + "', "
                    + "'" + contact.getName() + "', "
                    + "'" + contact.getPatronymic() + "', "
                    + "'" + contact.getMobilePhone() + "', "
                    + "'" + contact.getHomePhone() + "', "
                    + "'" + contact.getAddress() + "', "
                    + "'" + contact.getBirthDate() + "', "
                    + "'" + contact.getNotes() + "') "
            );
    }

    @Override
    public void delete(final Long id) throws SQLException {
        throw new IllegalStateException("not implemented in fake");
    }

    @Override
    public void edit(final Long id, final Contact contact) throws SQLException {
        throw new IllegalStateException("not implemented in fake");
    }

    @Override
    public Optional<Contact> byId(final Long id) throws SQLException {
        throw new IllegalStateException("not implemented in fake");
    }
}
