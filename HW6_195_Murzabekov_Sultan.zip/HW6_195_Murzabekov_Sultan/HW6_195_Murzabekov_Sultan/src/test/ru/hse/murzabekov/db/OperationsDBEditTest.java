package test.ru.hse.murzabekov.db;

import java.sql.SQLException;
import java.util.Collection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.hse.murzabekov.db.ApacheDerbyDB;
import ru.hse.murzabekov.db.Database;
import ru.hse.murzabekov.db.OperationsDB;
import ru.hse.murzabekov.model.Contact;

public class OperationsDBEditTest {
    private Database db;

    @AfterEach
    void tearDown() throws Exception {
        db.close();
    }

    @Test
    void editContactWorks() throws SQLException {
        db = new Database.Fake();
        db.createTable(ApacheDerbyDB.TABLE);
        final FakeOperations fake = new FakeOperations(db);
        fake.add(SimpleContact.value());
        final Contact upd = SimpleContact.another();
        new OperationsDB.Derby(db)
            .edit(fake.list().iterator().next().getId(), upd);
        final Collection<Contact> got = fake.list();
        Assertions.assertEquals(got.size(), 1);
        Assertions.assertTrue(
            upd.equalsAllIgnoreId(got.iterator().next())
        );
    }
}
