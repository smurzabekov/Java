package test.ru.hse.murzabekov.model;

import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import ru.hse.murzabekov.model.Contact;

class ContactTest {
    @Test
    void contactsWithSameNameSurnamePatronymicAreEqual() {
        final String surname = "surname";
        final String name = "name";
        final String patr = "patronymic";
        final Contact first = new Contact.Builder()
            .setSurname(surname)
            .setName(name)
            .setPatronymic(patr)
            .setId(12L)
            .build();
        final Contact second = new Contact.Builder()
            .setSurname(surname)
            .setName(name)
            .setPatronymic(patr)
            .setId(73L)
            .build();
        assertEquals(first, second);
    }

    @Test
    void hasPhoneWhenMobileIsSet() {
        final Contact.Builder builder = new Contact.Builder().setMobilePhone("+78887654123");
        assertTrue(builder.hasPhone());
    }

    @Test
    void notHasPhoneWhenBothAreAbsent() {
        final Contact.Builder builder = new Contact.Builder().setMobilePhone("-");
        assertFalse(builder.hasPhone());
    }

    @Test
    void failsToSetPhoneInWrongFormat() {
        Assertions.assertThrows(
            IllegalStateException.class,
            () -> new Contact.Builder().setMobilePhone("123")
        ) ;
    }

    @Test
    void failsToSetBirthDateInWrongFormat() {
        Assertions.assertThrows(
            IllegalStateException.class,
            () -> new Contact.Builder().setBirthDate("10/10/2013")
        ) ;
    }
}
