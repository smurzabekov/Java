package test.ru.hse.murzabekov.validation;

import ru.hse.murzabekov.validation.StrVal;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class StrValTest {
    @ParameterizedTest
    @ValueSource(strings = {"", " "})
    void notPresentedValues(final String line) {
        Assertions.assertFalse(new StrVal(line).present());
    }

    @Test
    void notPresentedForNull() {
        Assertions.assertFalse(new StrVal(null).present());
    }

    @Test
    void returnsPresentValues() {
        Assertions.assertTrue(new StrVal("some line").present());
    }
}
