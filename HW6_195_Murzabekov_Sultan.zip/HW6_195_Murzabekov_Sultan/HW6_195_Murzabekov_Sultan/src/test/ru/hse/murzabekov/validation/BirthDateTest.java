package test.ru.hse.murzabekov.validation;

import ru.hse.murzabekov.validation.BirthDate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class BirthDateTest {
    @ParameterizedTest
    @ValueSource(strings = {"2010.02.02", "30.02.2019", "05.05.2050", "wrong", "01/07/2010"})
    void notValidBirthDates(final String val) {
        Assertions.assertFalse(new BirthDate(val).valid());
    }

    @Test
    void notValidForNull() {
        Assertions.assertFalse(new BirthDate(null).valid());
    }

    @Test
    void returnsTrueIfCorrect() {
        Assertions.assertTrue(new BirthDate("21.10.2008").valid());
    }
}
