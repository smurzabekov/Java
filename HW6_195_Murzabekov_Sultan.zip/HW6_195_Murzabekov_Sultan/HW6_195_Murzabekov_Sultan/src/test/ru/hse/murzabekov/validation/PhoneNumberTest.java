package test.ru.hse.murzabekov.validation;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import ru.hse.murzabekov.validation.PhoneNumber;

class PhoneNumberTest {
    @ParameterizedTest
    @ValueSource(strings = {
        "+7(9991234567", "+7(999)1-23-45-67",
        "wrong", "12345",
        "+7999)1234567"
    })
    void notValidPhoneNumber(final String val) {
        Assertions.assertFalse(new PhoneNumber(val).valid());
    }

    @Test
    void notValidForNull() {
        Assertions.assertFalse(new PhoneNumber(null).valid());
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "+79991234567", "89991234567",
        "+7(999)1234567", "+7(999)123-4567",
        "+7999123-45-67", "+7(999)123-45-67",
    })
    void returnsTrueIfCorrect(final String phone) {
        Assertions.assertTrue(new PhoneNumber(phone).valid());
    }

}