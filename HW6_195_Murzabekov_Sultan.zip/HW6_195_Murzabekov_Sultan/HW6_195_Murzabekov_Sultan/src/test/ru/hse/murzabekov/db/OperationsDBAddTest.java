package test.ru.hse.murzabekov.db;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.hse.murzabekov.db.ApacheDerbyDB;
import ru.hse.murzabekov.db.Database;
import ru.hse.murzabekov.db.OperationsDB;
import ru.hse.murzabekov.model.Contact;

class OperationsDBAddTest {
    private Database db;

    @AfterEach
    void tearDown() throws Exception {
        db.close();
    }

    @Test
    void addContactWorks() throws SQLException {
        db = new Database.Fake();
        db.createTable(ApacheDerbyDB.TABLE);
        final OperationsDB derby = new OperationsDB.Derby(db);
        derby.add(SimpleContact.value());
        final Collection<Contact> contacts = new FakeOperations(db).list();
        Assertions.assertEquals(contacts.size(), 1);
        Assertions.assertTrue(
            SimpleContact.value().equalsAllIgnoreId(
                new ArrayList<>(contacts).get(0)
            )
        );
    }
}