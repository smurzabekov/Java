package test.ru.hse.murzabekov.ui;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.hse.murzabekov.ui.Command;

class CommandTest {
    @Test
    void returnsAlias() {
        Assertions.assertEquals(Command.ADD.alias(), "add");
    }
}