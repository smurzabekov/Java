package test.ru.hse.murzabekov.db;

import ru.hse.murzabekov.model.Contact;

public class SimpleContact {
    public static Contact value() {
        return new Contact.Builder()
            .setSurname("surname")
            .setName("name")
            .setPatronymic("patronymic")
            .setAddress("address")
            .setBirthDate("02.05.2015")
            .setHomePhone("+79257896542")
            .setMobilePhone("-")
            .setNotes("some notes")
            .build();
    }

    public static Contact another() {
        return new Contact.Builder()
            .setSurname("surname2")
            .setName("name")
            .setPatronymic("patronymic2")
            .setAddress("address")
            .setBirthDate("17.12.1958")
            .setHomePhone("-")
            .setMobilePhone("+79991234567")
            .setNotes("some notes")
            .build();
    }
}
