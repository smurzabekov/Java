package test.ru.hse.murzabekov.db;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.hse.murzabekov.db.ApacheDerbyDB;
import ru.hse.murzabekov.db.Database;
import ru.hse.murzabekov.db.OperationsDB;
import ru.hse.murzabekov.model.Contact;

class OperationsDBListTest {
    private Database db;

    @AfterEach
    void tearDown() throws Exception {
        db.close();
    }

    @Test
    void listContactWorks() throws SQLException {
        db = new Database.Fake();
        db.createTable(ApacheDerbyDB.TABLE);
        final FakeOperations fake = new FakeOperations(db);
        final Contact contact = SimpleContact.another();
        fake.add(SimpleContact.value());
        fake.add(contact);
        final Collection<Contact> got = new OperationsDB.Derby(db).list();
        final Collection<Contact> expected = Arrays.asList(SimpleContact.value(), contact);
        Assertions.assertEquals(got.size(), expected.size());
        Assertions.assertTrue(
            got.containsAll(expected) && expected.containsAll(got)
        );
    }
}