package ru.hse.murzabekov.validation;

/**
 * Validation of input line.
 */
public final class StrVal {

    private final String value;

    public StrVal(final String value) {
        this.value = value;
    }

    /**
     * Checks whether input line not blank.
     * @return true if line contains anything, false otherwise.
     */
    public boolean present() {
        return value != null && !value.isBlank();
    }
}
