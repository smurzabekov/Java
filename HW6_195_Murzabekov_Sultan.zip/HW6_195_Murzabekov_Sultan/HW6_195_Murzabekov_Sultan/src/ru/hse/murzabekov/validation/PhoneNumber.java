package ru.hse.murzabekov.validation;

import java.util.regex.Pattern;

/**
 * Validation of input phone number.
 */
public final class PhoneNumber {

    private static Pattern PTRN = Pattern.compile(
        "^([+]?\\d(\\d\\d\\d|[(]{1}\\d\\d\\d[)]{1})\\d\\d\\d[-]?\\d\\d[-]?\\d\\d|[-]{1})$"
    );

    private final String value;

    public PhoneNumber(final String value) {
        this.value = value;
    }

    /**
     * Checks whether input phone number is valid.
     * @return true if phone number is valid, false otherwise.
     */
    public boolean valid() {
        return value != null && PTRN.matcher(value).matches();
    }

    /**
     * Required format.
     * @return Tips with required format.
     */
    public static String format() {
        return "Required format for phone number: [+]7[(]999[)]123[-]45[-]67 or `-`";
    }
}
