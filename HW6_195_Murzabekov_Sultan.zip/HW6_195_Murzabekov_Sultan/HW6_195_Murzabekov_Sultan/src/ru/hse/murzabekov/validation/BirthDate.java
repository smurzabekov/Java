package ru.hse.murzabekov.validation;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.regex.Pattern;

/**
 * Validation of input birth date.
 */
public final class BirthDate {

    private static Pattern PTRN = Pattern.compile("^\\d\\d\\.\\d\\d\\.\\d\\d\\d\\d$");

    private final String value;

    public BirthDate(final String value) {
        this.value = value;
    }

    /**
     * Checks whether input birth date is valid. Also, this date should be earlier
     * than current date.
     * @return true if birth date is valid, false otherwise.
     */
    public boolean valid() {
        try {
            final SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
            format.setLenient(false);
            return value != null
                && PTRN.matcher(value).matches()
                && format.parse(value).before(Date.from(Instant.now()));
        } catch (final IllegalArgumentException | ParseException exc) {
            return false;
        }
    }

    /**
     * Required format.
     * @return Tips with required format.
     */
    public static String format() {
        return "Required format for birthdate: dd.mm.yyyy. Date should be valid";
    }
}
