package ru.hse.murzabekov.model;

import java.util.Objects;
import ru.hse.murzabekov.validation.BirthDate;
import ru.hse.murzabekov.validation.PhoneNumber;
import ru.hse.murzabekov.validation.StrVal;

/**
 * Represents a phonebook contact.
 */
public final class Contact {
    /**
     * Unique identification.
     */
    private Long id;

    /**
     * Name.
     */
    private String name;

    /**
     * Surname.
     */
    private String surname;

    /**
     * Patronymic.
     */
    private String patronymic;

    /**
     * Home phone number.
     */
    private String homePhone;

    /**
     * Mobile phone number.
     */
    private String mobilePhone;

    /**
     * Date of birth.
     */
    private String birthDate;

    /**
     * Address.
     */
    private String address;

    /**
     * Notes about a contact.
     */
    private String notes;

    /**
     * @return Id of a contact.
     */
    public Long getId() {
        return id;
    }

    /**
     * @return Name of a contact.
     */
    public String getName() {
        return name;
    }

    /**
     * @return Surname of a contact.
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @return Patronymic of a contact.
     */
    public String getPatronymic() {
        return patronymic;
    }

    /**
     * @return Home phone of a contact.
     */
    public String getHomePhone() {
        return homePhone;
    }

    /**
     * @return Mobile phone of a contact.
     */
    public String getMobilePhone() {
        return mobilePhone;
    }

    /**
     * @return Date of birth of a contact.
     */
    public String getBirthDate() {
        return birthDate;
    }

    /**
     * @return Address of a contact.
     */
    public String getAddress() {
        return address;
    }

    /**
     * @return Notes about a contact.
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Private constructor to prevent creation without using a builder.
     */
    private Contact(Builder builder) {
        this.id = builder.id;
        this.surname = builder.surname;
        this.name = builder.name;
        this.patronymic = builder.patronymic;
        this.mobilePhone = builder.mobilePhone;
        this.homePhone = builder.homePhone;
        this.address = builder.address;
        this.birthDate = builder.birthDate;
        this.notes = builder.notes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Contact)) {
            return false;
        }
        final Contact contact = (Contact) o;
        return getSurname().equals(contact.getSurname()) &&
            getName().equals(contact.getName()) &&
            Objects.equals(getPatronymic(), contact.getPatronymic());
    }

    public boolean equalsAllIgnoreId(final Contact contact) {
        return getSurname().equals(contact.getSurname()) &&
            getName().equals(contact.getName()) &&
            Objects.equals(getPatronymic(), contact.getPatronymic()) &&
            Objects.equals(getAddress(), contact.getAddress()) &&
            Objects.equals(getBirthDate(), contact.getBirthDate()) &&
            Objects.equals(getHomePhone(), contact.getHomePhone()) &&
            Objects.equals(getMobilePhone(), contact.getMobilePhone()) &&
            Objects.equals(getNotes(), contact.getNotes());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSurname(), getName(), getPatronymic());
    }

    @Override
    public String toString() {
        return "{" +
            "id='" + id + '\'' +
            ", surname='" + surname + '\'' +
            ", name='" + name + '\'' +
            ", patronymic='" + patronymic + '\'' +
            ", mobilePhone='" + mobilePhone + '\'' +
            ", homePhone='" + homePhone + '\'' +
            ", address='" + address + '\'' +
            ", birthDate=" + birthDate +
            ", notes='" + notes + '\'' +
            "}\n";
    }

    public static class Builder {

        private Long id;

        private String name;

        private String surname;

        private String patronymic;

        private String homePhone;

        private String mobilePhone;

        private String birthDate;

        private String address;

        private String notes;

        public Builder() {
        }

        public Builder setId(final Long id) {
            this.id = id;
            return this;
        }

        public Builder setSurname(String surname) {
            if (!new StrVal(surname).present()) {
                throw new IllegalStateException("Failed to set empty surname");
            }
            this.surname = surname;
            return this;
        }

        public Builder setName(final String name) {
            if (!new StrVal(name).present()) {
                throw new IllegalStateException("Failed to set empty name");
            }
            this.name = name;
            return this;
        }

        public Builder setPatronymic(final String patronymic) {
            this.patronymic = patronymic;
            return this;
        }

        public Builder setMobilePhone(final String mobilePhone) {
            if (!new PhoneNumber(mobilePhone).valid()) {
                throw new IllegalStateException(
                    String.format(
                        "Failed to set mobile phone: %s. %s",
                        mobilePhone,
                        PhoneNumber.format()
                    )
                );
            }
            this.mobilePhone = mobilePhone;
            return this;
        }

        public Builder setHomePhone(final String homePhone) {
            if (!new PhoneNumber(homePhone).valid()) {
                throw new IllegalStateException(
                    String.format(
                        "Failed to set home phone: %s. %s",
                        homePhone,
                        PhoneNumber.format()
                    )
                );
            }
            this.homePhone = homePhone;
            return this;
        }

        public Builder setAddress(final String address) {
            this.address = address;
            return this;
        }

        public Builder setBirthDate(final String birthDate) {
            if (!new BirthDate(birthDate).valid()) {
                throw new IllegalStateException(
                    String.format(
                        "Failed to set birthdate: %s. %s",
                        birthDate,
                        BirthDate.format()
                    )
                );
            }
            this.birthDate = birthDate;
            return this;
        }

        public Builder setNotes(final String notes) {
            this.notes = notes;
            return this;
        }

        public Contact build() {
            return new Contact(this);
        }

        /**
         * Checks existence of phone number.
         * @return Does contact have mobile or home phone?
         */
        public boolean hasPhone() {
            return (new StrVal(mobilePhone).present() && !mobilePhone.equals("-"))
                || (new StrVal(homePhone).present() && !homePhone.equals("-"));
        }
    }
}
