package ru.hse.murzabekov.ui;

public enum Command {
    LIST("list"),
    ADD("add"),
    DELETE("delete"),
    EDIT("edit"),
    ABOUT("about"),
    IMPORT("import"),
    EXPORT("export"),
    EXIT("exit");

    private final String name;

    Command(final String name) {
        this.name = name;
    }

    public String alias() {
        return name;
    }
}
