package ru.hse.murzabekov;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import ru.hse.murzabekov.db.ApacheDerbyDB;
import ru.hse.murzabekov.db.Data;
import ru.hse.murzabekov.db.Database;
import ru.hse.murzabekov.db.OperationsDB;
import ru.hse.murzabekov.model.Contact;
import ru.hse.murzabekov.ui.Command;
import ru.hse.murzabekov.validation.BirthDate;
import ru.hse.murzabekov.validation.PhoneNumber;
import ru.hse.murzabekov.validation.StrVal;

public class Main {

    private static final String OLD = "#!#";

    private static final String SEPARATOR = ";";

    public static void main(String[] args) throws Exception {
        final Collection<String> commands = Arrays.stream(Command.values())
            .map(Command::alias)
            .collect(Collectors.toList());
        try (
            InputStreamReader isr = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(isr);
            Database db = new ApacheDerbyDB()
        ) {
            db.createTable("Contact");
            System.out.println("Hi! There are available commands: " + commands);
            while (true) {
                System.out.print("> ");
                String line = br.readLine();
                if (line.equals(Command.LIST.alias())) {
                    final Collection<Contact> contacts = new OperationsDB.Derby(db).list();
                    if (contacts.isEmpty()) {
                        System.out.println("There are no contacts in the phone book yet");
                    } else {
                        contacts.forEach(System.out::print);
                    }
                } else if (line.equals(Command.ADD.alias())) {
                    final Contact contact = inputContact(br);
                    new OperationsDB.Derby(db).add(contact);
                    System.out.println("Contact was successfully added!");
                } else if (line.equals(Command.DELETE.alias())) {
                    final Optional<Long> id = idOfItemFromDb(
                        "Input id of record which should be removed: \n>", br, db
                    );
                    if (id.isEmpty()) {
                        continue;
                    }
                    new OperationsDB.Derby(db).delete(id.get());
                    System.out.println("Item was successfully removed!");
                } else if (line.equals(Command.EDIT.alias())) {
                    final Optional<Long> id = idOfItemFromDb(
                        "Input id of record which should be edited: \n>", br, db
                    );
                    if (id.isEmpty()) {
                        continue;
                    }
                    final Contact upd = editedItem(id.get(), br, db);
                    new OperationsDB.Derby(db).edit(id.get(), upd);
                    System.out.println("Item was successfully edited!");
                } else if (line.equals(Command.ABOUT.alias())) {
                    System.out.println("Murzabekov Sultan, BSE 195");
                } else if (line.equals(Command.IMPORT.alias())) {
                    importContacts(br, db);
                    System.out.println("Import operation finished!");
                } else if (line.equals(Command.EXPORT.alias())) {
                    final String file = "contacts.csv";
                    new Data.Csv(SEPARATOR).exportAll(
                        new OperationsDB.Derby(db).list(),
                        Path.of(file)
                    );
                    System.out.printf("Contacts were exported to %s%n", file);
                } else if (line.equals(Command.EXIT.alias())) {
                    System.out.println("The program will finish!");
                    break;
                } else {
                    System.out.println("You've entered an unknown command.");
                    System.out.println("Available commands: " + commands);
                }
            }
        } catch (final IllegalStateException exc) {
            exc.getCause().printStackTrace();
        } catch (final IOException exc) {
            System.out.println("There are some problems during reading values from console.\n");
            exc.printStackTrace();
        }
    }

    private static Contact inputContact(final BufferedReader br) throws IOException {
        String line;
        Contact.Builder builder = new Contact.Builder();
        builder = builder.setSurname(lineWithCheckStrVal("Input surname", br, false));
        builder = builder.setName(lineWithCheckStrVal("Input name", br, false));
        builder = builder.setPatronymic(
            lineWithCheckStrVal("Input patronymic (or '-' in case of absence)", br, false)
        );
        System.out.print("Input birthdate: \n>");
        while (!new BirthDate(line = br.readLine()).valid()) {
            System.out.println(BirthDate.format());
            System.out.print("Input birthdate: \n>");
        }
        builder = builder.setBirthDate(line);
        builder = builder.setMobilePhone(
            lineWithCheckPhone("Input mobile phone (or '-' in case of absence)", br, false)
        );
        do {
            builder = builder.setHomePhone(
                lineWithCheckPhone("Input home phone (or '-' in case of absence)", br, false)
            );
            if (!builder.hasPhone()) {
                System.out.println("Please, input home phone because one of phones should exist");
            }
        } while (!builder.hasPhone());
        builder = builder.setAddress(lineWithCheckStrVal("Input address (or '-' in case of absence)", br, false));
        builder = builder.setNotes(lineWithCheckStrVal("Input notes (or '-' in case of absence)", br, false));
        return builder.build();
    }

    private static String lineWithCheckStrVal(
        final String msg, final BufferedReader br, final boolean edit
    ) throws IOException {
        String line;
        final String text;
        if (edit) {
            text = String.format("%s [or symbols '%s' to remain old value]: \n>", msg, OLD);
        } else {
            text = String.format("%s: \n>", msg);
        }
        System.out.print(text);
        while (!new StrVal(line = br.readLine()).present() && !(edit && line.equals(OLD))) {
            System.out.print(text);
        }
        return line;
    }

    private static String lineWithCheckPhone(
        final String msg, final BufferedReader br, final boolean edit
    ) throws IOException {
        String line;
        final String text;
        if (edit) {
            text = String.format("%s [or symbols '%s' to remain old value]: \n>", msg, OLD);
        } else {
            text = String.format("%s: \n>", msg);
        }
        System.out.print(text);
        while (!new PhoneNumber(line = br.readLine()).valid() && !(edit && line.equals(OLD))) {
            System.out.print(text);
        }
        return line;
    }

    private static Optional<Long> idOfItemFromDb(
        final String msg, final BufferedReader br, final Database db
    ) throws SQLException, IOException {
        final Collection<Contact> contacts = new OperationsDB.Derby(db).list();
        if (contacts.isEmpty()) {
            System.out.println("There are no contacts in the phone book yet.");
            return Optional.empty();
        } else {
            contacts.forEach(System.out::print);
        }
        final Set<String> ids = new HashSet<>();
        contacts.forEach(cont -> ids.add(String.valueOf(cont.getId())));
        System.out.print(msg);
        String line;
        while ((line = br.readLine()) == null || !ids.contains(line)) {
            System.out.println("Id should exist");
            System.out.println("Available ids: " + ids);
            System.out.print(msg);
        }
        return Optional.of(Long.parseLong(line));
    }

    private static void importContacts(final BufferedReader br, final Database db)
        throws SQLException, IOException {
        System.out.print("Input name of source csv file: \n>");
        String line;
        while (!new StrVal(line = br.readLine()).present()) {
            System.out.print("Input name of source csv file: \n>");
        }
        final Collection<Contact> parsed = new Data.Csv(SEPARATOR).importFrom(Path.of(line));
        if (!parsed.isEmpty()) {
            final OperationsDB derby = new OperationsDB.Derby(db);
            final Collection<Contact> existed = derby.list();
            for (final Contact cont : parsed) {
                if (!existed.contains(cont)) {
                    derby.add(cont);
                } else {
                    System.out.println("Contact was not added as it exists");
                    System.out.print(cont);
                }
            }
        }
    }

    private static Contact editedItem(final Long id, final BufferedReader br, final Database db)
        throws SQLException, IOException {
        final Contact existed = new OperationsDB.Derby(db).byId(id).orElseThrow();
        String line;
        Contact.Builder builder = new Contact.Builder();
        builder = builder.setSurname(
            selectVal(
                lineWithCheckStrVal(String.format("Input surname (old_val: %s)", existed.getSurname()), br, true),
                existed.getSurname()
            )
        );
        builder = builder.setName(
            selectVal(
                lineWithCheckStrVal(String.format("Input name (old_val: %s)", existed.getName()), br, true),
                existed.getName()
            )
        );
        builder = builder.setPatronymic(
            selectVal(
                lineWithCheckStrVal(
                    String.format("Input patronymic (or '-' in case of absence) (old_val: %s)", existed.getPatronymic()),
                    br,
                    true
                ),
                existed.getPatronymic()
            )
        );
        final String birth = String.format(
            "Input birthdate (old_val: %s) [or symbols '%s' to remain old value]: \n>",
            existed.getBirthDate(),
            OLD
        );
        System.out.print(birth);
        try {
            while (!new BirthDate(line = br.readLine()).valid() && !line.equals(OLD)) {
                System.out.println(BirthDate.format());
                System.out.print(birth);
            }
            builder = builder.setBirthDate(selectVal(line, existed.getBirthDate()));
        } catch (Throwable thr) {
            thr.printStackTrace();
        }
        builder = builder.setMobilePhone(
            selectVal(
                lineWithCheckPhone(
                    String.format("Input mobile phone (or '-' in case of absence) (old_val: %s)", existed.getMobilePhone()),
                    br,
                    true
                ),
                existed.getMobilePhone()
            )
        );
        do {
            builder = builder.setHomePhone(
                selectVal(
                    lineWithCheckPhone(
                        String.format("Input home phone (or '-' in case of absence) (old_val: %s)", existed.getHomePhone()),
                        br,
                        true
                    ),
                    existed.getHomePhone()
                )
            );
            if (!builder.hasPhone()) {
                System.out.println("Please, input home phone because one of them should exist");
            }
        } while (!builder.hasPhone());
        builder = builder.setAddress(
            selectVal(
                lineWithCheckStrVal(String.format("Input address (old_val: %s)", existed.getAddress()), br, true),
                existed.getAddress()
            )
        );
        builder = builder.setNotes(
            selectVal(
                lineWithCheckStrVal(String.format("Input notes (old_val: %s)", existed.getNotes()), br, true),
                existed.getNotes()
            )
        );
        return builder.build();
    }

    private static String selectVal(final String upd, final String old) {
        if (upd.trim().equals(OLD)) {
            return old;
        } else {
            return upd;
        }
    }
}
