package ru.hse.murzabekov.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public final class ApacheDerbyDB implements Database {

    public static final String TABLE = "Contact";

    static final String PROTOCOL = "jdbc:derby:";

    static final String DB_NAME = "phoneBookDB";

    static final String CREATE_TABLE = String.format("CREATE TABLE %s ", TABLE)
        + "(ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY, "
        + "SURNAME VARCHAR(128) NOT NULL, "
        + "NAME VARCHAR(64) NOT NULL, "
        + "PATRONYMIC VARCHAR(64) NOT NULL, "
        + "MOBILE_PHONE VARCHAR(16), "
        + "HOME_PHONE VARCHAR(16), "
        + "ADDRESS VARCHAR(256), "
        + "BIRTH VARCHAR(16), "
        + "NOTES VARCHAR(1024)) ";

    private Connection conn;

    public ApacheDerbyDB() {
        this.conn = createConnection();
    }

    @Override
    public Connection getConnection() {
        return conn;
    }

    @Override
    public void createTable(final String tableName) {
        if (!new ExistenceTable(TABLE, conn).exists()) {
            try {
                Statement statement = conn.createStatement();
                statement.execute(CREATE_TABLE);

            } catch( final SQLException exc){
                throw new IllegalStateException("Failed to create statement. ", exc);
            }
        }
    }

    @Override
    public void close() throws Exception {
        if (conn != null) {
            conn.close();
        }
    }

    private Connection createConnection() {
        try {
            return DriverManager.getConnection(PROTOCOL + DB_NAME + ";create=true");
        } catch (final SQLException exc) {
            throw new IllegalStateException("Failed to create connection. ", exc);
        }
    }
}
