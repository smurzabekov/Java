package ru.hse.murzabekov.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import ru.hse.murzabekov.model.Contact;
import ru.hse.murzabekov.utils.Utils;

/**
 * Encapsulates basic operations for interaction with database.
 */
public interface OperationsDB {
    /**
     * Obtains collection of items from database.
     * @return Collection of items from database.
     * @throws SQLException In case of sql exception
     */
   Collection<Contact> list() throws SQLException;

    /**
     * Adds a new contact to database.
     * @param contact Contact which should be added
     * @throws SQLException In case of sql exception
     */
    void add(Contact contact) throws SQLException;

    /**
     * Removes contact by id.
     * @param id Id of contact which should be removed from database
     * @throws SQLException In case of sql exception
     */
    void delete(Long id) throws SQLException;

    /**
     * Updates contact by specified id
     * @param id Id of contact which should be edited from database
     * @param contact Contact with some updated values
     * @throws SQLException In case of sql exception
     */
    void edit(Long id, Contact contact) throws SQLException;

    /**
     * Obtains contact by id from database.
     * @param id Id of contact which should be obtained from database
     * @return Contact in case of existence, empty otherwise.
     * @throws SQLException In case of sql exception
     */
    Optional<Contact> byId(Long id) throws SQLException;

    final class Derby implements OperationsDB {

        private Database db;

        public Derby(Database db) {
            this.db = db;
        }

        @Override
        public Collection<Contact> list() throws SQLException {
            final List<Contact> contacts = new ArrayList<>();
            ResultSet resSet = db.getConnection().createStatement()
                .executeQuery(String.format("SELECT * FROM %s ", ApacheDerbyDB.TABLE));
            Utils.addContactsTo(resSet, contacts);
            return contacts;
        }

        @Override
        public void add(final Contact contact) throws SQLException {
            db.getConnection().createStatement()
                .executeUpdate(
                    String.format("INSERT INTO %s ", ApacheDerbyDB.TABLE)
                    + " (SURNAME, NAME, PATRONYMIC, MOBILE_PHONE, HOME_PHONE, ADDRESS, BIRTH, NOTES) VALUES ( "
                    + "'" + updatedStr(contact.getSurname()) + "', "
                    + "'" + updatedStr(contact.getName()) + "', "
                    + "'" + updatedStr(contact.getPatronymic()) + "', "
                    + "'" + contact.getMobilePhone() + "', "
                    + "'" + contact.getHomePhone() + "', "
                    + "'" + updatedStr(contact.getAddress()) + "', "
                    + "'" + contact.getBirthDate() + "', "
                    + "'" + updatedStr(contact.getNotes()) + "') "
                );
        }

        @Override
        public void delete(final Long id) throws SQLException {
            db.getConnection().createStatement()
                .executeUpdate(
                    String.format("DELETE FROM %s WHERE id=%d", ApacheDerbyDB.TABLE, id)
                );
        }

        @Override
        public void edit(final Long id, final Contact contact) throws SQLException {
            db.getConnection().createStatement()
                .executeUpdate(
                    String.format("UPDATE %s SET ", ApacheDerbyDB.TABLE)
                    + String.format("surname='%s', ", updatedStr(contact.getSurname()))
                    + String.format("name='%s', ", updatedStr(contact.getName()))
                    + String.format("patronymic='%s', ", updatedStr(contact.getPatronymic()))
                    + String.format("mobile_phone='%s', ", contact.getMobilePhone())
                    + String.format("home_phone='%s', ", contact.getHomePhone())
                    + String.format("birth='%s', ", contact.getBirthDate())
                    + String.format("address='%s', ", updatedStr(contact.getAddress()))
                    + String.format("notes='%s' ", updatedStr(contact.getNotes()))
                    + String.format("WHERE id=%d", id)
                );
        }

        @Override
        public Optional<Contact> byId(final Long id) throws SQLException {
            final List<Contact> contacts = new ArrayList<>();
            ResultSet resSet = db.getConnection().createStatement()
                .executeQuery(
                    String.format("SELECT * FROM %s WHERE id=%d", ApacheDerbyDB.TABLE, id)
                );
            Utils.addContactsTo(resSet, contacts);
            if (contacts.isEmpty()) {
                return Optional.empty();
            }
            return Optional.of(contacts.get(0));
        }

        private static String updatedStr(final String line) {
            return line.replaceAll("'",  "`");
        }
    }
}
