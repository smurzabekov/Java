package ru.hse.murzabekov.db;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import ru.hse.murzabekov.model.Contact;
import ru.hse.murzabekov.utils.Utils;

/**
 * Manipulation with data in database. Export existed
 * data from database or import new data from file.
 */
public interface Data {
    /**
     * Import contacts from passed file. Ignore first line in csv file
     * because it contains column names.
     * @param in Source file with contacts
     * @return Contacts which were obtained from passed file.
     */
    Collection<Contact> importFrom(Path in);

    void exportAll(Collection<Contact> contacts, Path out) throws FileNotFoundException;

    final class Csv implements Data {

        private final String separator;

        public Csv(final String separator) {
            this.separator = separator;
        }

        @Override
        public Collection<Contact> importFrom(final Path in) {
            final List<Contact> contacts = new ArrayList<>();
            if (!Utils.doesFileExist(in.toString())) {
                System.out.println("File does not exist");
                return contacts;
            }
            try (BufferedReader br = new BufferedReader(new FileReader(in.toFile()))) {
                String line;
                br.readLine();
                while ((line = br.readLine()) != null) {
                    Contact newContact = parseFromCSV(line);
                    if (newContact != null) {
                        contacts.add(newContact);
                    }
                }
            } catch (final Exception exc) {
                System.out.printf("Error occurred during contacts from %s.%n", in);
                System.out.printf("Message: %s.%n", exc.getMessage());
                return contacts;
            }
            return contacts;
        }

        @Override
        public void exportAll(
            final Collection<Contact> contacts,
            final Path out
        ) throws FileNotFoundException {
            final File csvout = out.toFile();
            try (PrintWriter pw = new PrintWriter(csvout)) {
                pw.println(
                    String.join(separator, "surname", "name", "patronymic",
                        "mobile_phone", "home_phone", "address", "birth", "notes")
                );
                contacts.stream()
                    .map(this::convertToCsvLine)
                    .forEach(pw::println);
            }
        }

        private String convertToCsvLine(final Contact contact) {
            final List<String> vals = new ArrayList<>();
            vals.add(replacedSeparatorIn(contact.getSurname()));
            vals.add(replacedSeparatorIn(contact.getName()));
            vals.add(replacedSeparatorIn(contact.getPatronymic()));
            vals.add(contact.getBirthDate());
            vals.add(contact.getMobilePhone());
            vals.add(contact.getHomePhone());
            vals.add(replacedSeparatorIn(contact.getAddress()));
            vals.add(replacedSeparatorIn(contact.getNotes()));
            return String.join(separator, vals);
        }

        /**
         * Parses a contact from CSV formatted line.
         *
         * @param info Contact in string format.
         * Values order: surname, name, patronymic, mobile phone number,
         * home phone number, date of birth, address, notes.
         * @return Contact instance with values extracted from passed string.
         */
        private Contact parseFromCSV(final String info) {
            String[] data = info.split(separator, -1);
            return new Contact.Builder()
                .setSurname(data[0])
                .setName(data[1])
                .setPatronymic(data[2])
                .setBirthDate(data[3])
                .setMobilePhone(data[4])
                .setHomePhone(data[5])
                .setAddress(data[6])
                .setNotes(data[7])
                .build();
        }

        private String replacedSeparatorIn(final String str) {
            return str.replaceAll(separator, ",");
        }
    }
}
