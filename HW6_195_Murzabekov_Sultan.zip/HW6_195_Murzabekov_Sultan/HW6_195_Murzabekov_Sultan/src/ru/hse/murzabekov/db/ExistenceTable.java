package ru.hse.murzabekov.db;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

/**
 * Checks existence of table in database.
 */
public final class ExistenceTable {

    private final String table;

    private final Connection conn;

    /**
     * Ctor.
     * @param table Table existence of which should be checked
     * @param conn Connection to database where check would be held
     */
    public ExistenceTable(final String table, final Connection conn) {
        this.table = table.toLowerCase();
        this.conn = conn;
    }

    /**
     * Checks existence of table in database.
     * @return true if table exists, false otherwise.
     */
    public boolean exists() {
        final Set<String> tables;
        try {
            tables = getDBTables();
        } catch (final SQLException exc) {
            throw new IllegalStateException("Failed to read existed tables", exc);
        }
        return tables.contains(this.table);
    }

    private Set<String> getDBTables() throws SQLException {
        final Set<String> existed = new HashSet<>();
        final DatabaseMetaData dbmeta = conn.getMetaData();
        readDBTable(existed, dbmeta, "TABLE", null);
        readDBTable(existed, dbmeta, "VIEW", null);
        return existed;
    }

    private static void readDBTable(
        final Set<String> set,
        final DatabaseMetaData dbmeta,
        final String searchCriteria,
        final String schema
    ) throws SQLException {
        final String[] criteria = new String[]{searchCriteria};
        ResultSet rs = dbmeta.getTables(null, schema, null, criteria);
        while (rs.next()) {
            set.add(rs.getString("TABLE_NAME").toLowerCase());
        }
    }
}
