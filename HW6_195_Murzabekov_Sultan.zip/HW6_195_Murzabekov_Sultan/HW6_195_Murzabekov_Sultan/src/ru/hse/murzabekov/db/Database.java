package ru.hse.murzabekov.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Interaction with database.
 */
public interface Database extends AutoCloseable {
    /**
     * Obtains connection to database.
     * @return Connection to database.
     */
    Connection getConnection();

    /**
     * Create a new table in database.
     * @param tableName Table name which should be created
     */
    void createTable(String tableName);

    final class Fake implements Database {

        private static final String PROTOCOL = "jdbc:derby:";

        private Connection conn;

        public Fake() {
            this.conn = createConnection();
        }

        @Override
        public Connection getConnection() {
            return conn;
        }

        @Override
        public void createTable(final String tableName) {
            if (!new ExistenceTable(ApacheDerbyDB.TABLE, conn).exists()) {
                try {
                    Statement statement = conn.createStatement();
                    statement.execute(ApacheDerbyDB.CREATE_TABLE);

                } catch( final SQLException exc){
                    throw new IllegalStateException("Failed to create statement. ", exc);
                }
            }
        }

        @Override
        public void close() throws Exception {
            if (conn != null) {
                conn.close();
            }
        }

        private Connection createConnection() {
            try {
                return DriverManager.getConnection(
                    ApacheDerbyDB.PROTOCOL + "memory:" + ApacheDerbyDB.DB_NAME + ";create=true"
                );
            } catch (final SQLException exc) {
                throw new IllegalStateException("Failed to create connection. ", exc);
            }
        }
    }
}
