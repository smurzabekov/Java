package ru.hse.murzabekov.utils;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Objects;
import ru.hse.murzabekov.model.Contact;

public final class Utils {
    /**
     * Checks if file in the passed path exists and is not a directory.
     * @param path Path to the file which existence is checked
     * @return true in case of existence and is not a directory, false otherwise.
     */
    public static boolean doesFileExist(String path) {
        Objects.requireNonNull(path);
        File f = new File(path);
        return f.exists() && !f.isDirectory();
    }

    /**
     * Add contacts from result set to collection.
     * @param res Result set
     * @param contacts Collection of contacts
     * @throws SQLException In case of sql exception
     */
    public static void addContactsTo(final ResultSet res, final Collection<Contact> contacts)
        throws SQLException {
        while (res.next()) {
            contacts.add(
                new Contact.Builder()
                    .setId(Long.valueOf(res.getString("id")))
                    .setSurname(res.getString("surname"))
                    .setName(res.getString("name"))
                    .setPatronymic(res.getString("patronymic"))
                    .setMobilePhone(res.getString("mobile_phone"))
                    .setHomePhone(res.getString("home_phone"))
                    .setAddress(res.getString("address"))
                    .setBirthDate(res.getString("birth"))
                    .setNotes(res.getString("notes"))
                    .build()
            );
        }
    }
}
