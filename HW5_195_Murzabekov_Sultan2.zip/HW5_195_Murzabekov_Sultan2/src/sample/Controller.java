package sample;
import java.net.URL;
import java.time.LocalDate;
import java.time.Month;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;

public class Controller {

    @FXML private TextField filterField;

    @FXML private TableView<Contact> tableView;

    @FXML private TableColumn<Contact, String> firstNameColoumn;

    @FXML private TableColumn<Contact, String> lastNameColoumn;

    @FXML private TableColumn<Contact, String> patronymicColoumn;

    @FXML private TableColumn<Contact, String> mobilePhoneColoumn;

    @FXML private TableColumn<Contact, String> addressColoumn;

    @FXML private TableColumn<Contact, LocalDate> birthdayColoumn;

    @FXML private TableColumn<Contact, String> commentsColoumn;

    @FXML private ResourceBundle resources;

    @FXML private URL location;

    @FXML
    void initialize() {
        firstNameColoumn.setCellValueFactory(new PropertyValueFactory<Contact, String>("FirstName"));
        lastNameColoumn.setCellValueFactory(new PropertyValueFactory<Contact, String>("LastName"));
        patronymicColoumn.setCellValueFactory(new PropertyValueFactory<Contact, String>("Patronymic"));
        mobilePhoneColoumn.setCellValueFactory(new PropertyValueFactory<Contact, String>("PhoneNumber"));
        addressColoumn.setCellValueFactory(new PropertyValueFactory<Contact, String>("Address"));
        birthdayColoumn.setCellValueFactory(new PropertyValueFactory<Contact, LocalDate>("Birthday"));
        commentsColoumn.setCellValueFactory(new PropertyValueFactory<Contact, String>("Comment"));

        tableView.setItems(getContacts());
        FilteredList<Contact> filteredData = new FilteredList<Contact>(getContacts(), b -> true);
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(person -> {


                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }


                String lowerCaseFilter = newValue.toLowerCase();

                if (person.getFirstName().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
                    return true;
                } else if (person.getLastName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                }
                else if (String.valueOf(person.getPatronymic()).indexOf(lowerCaseFilter)!=-1)
                    return true;
                else if (String.valueOf(person.getPhoneNumber()).indexOf(lowerCaseFilter)!=-1)
                    return true;
                else if (String.valueOf(person.getAddress()).indexOf(lowerCaseFilter)!=-1)
                    return true;
                else
                    return false;
            });
        });
        SortedList<Contact> sortedData = new SortedList<>(filteredData);

        sortedData.comparatorProperty().bind(tableView.comparatorProperty());

        tableView.setItems(sortedData);
    }
    public ObservableList<Contact> getContacts(){
        ObservableList<Contact> contacts = FXCollections.observableArrayList();
        contacts.add(new Contact("Frank","Sinatra", "serikovich", "+5345667890", "sandykta 3",
                LocalDate.of(1915, Month.DECEMBER, 12), "hui"));
        contacts.add(new Contact("dfv","sds", "serikovich", "+5673456890", "sandykta 3",
                LocalDate.of(1915, Month.DECEMBER, 12), "hui"));
        contacts.add(new Contact("Fradfvdfnk","dfvdfv", "serikovich", "+567345890", "sandykta 3",
                LocalDate.of(1915, Month.DECEMBER, 12), "hui"));

        return contacts;
    }

    public void end(ActionEvent actionEvent) {
        System.exit(0);
    }

    public void About(ActionEvent actionEvent) {
        Alert spravkaAlert = new Alert(Alert.AlertType.INFORMATION);
        spravkaAlert.setHeaderText("Справка");
        spravkaAlert.setContentText("Мурзабеков Султан БПИ195");
        spravkaAlert.showAndWait();
    }

    public void edit(ActionEvent actionEvent) {
    }

    public void add(ActionEvent actionEvent) {
    }
}
