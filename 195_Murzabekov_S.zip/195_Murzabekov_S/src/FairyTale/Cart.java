public class Cart {
    /**
     *  Переменные статичные описывающие местонахождение на координатоной прямой.
     */
    private static double x, y;

    /**
     * Геттер для координаты Х.
     * @return Х
     */
    public double getX() {
        return x;
    }

    /**
     * Сеттер задающий координату Х.
     * @param newX принимает значение Х
     */
    public void setX(double newX) {
        x = newX;
    }

    /**
     * Геттер для координаты Y.
     * @return Y
     */
    public double getY() {
        return y;
    }

    /**
     * Сеттер задающий координату Y.
     * @param newY принимает значение Y
     */
    public void setY(double newY) {
        y = newY;
    }

    /**
     * Конструктор поумолчанию.
     */
    public Cart() {
        x = 0;
        y = 0;
    }

    /**
     * Конструктор с параметрами.
     * @param x координата Х
     * @param y координата Y
     */
    public Cart(double x, double y) {
        Cart.x = x;
        Cart.y = y;
    }

    /**
     * Метод возвращающий строку информирующую о местонахождении тележки.
     * @return местонахождение
     */
    @Override
    public String toString() {
        return String.format("Cart is on [%.2f, %.2f].", x, y);
    }

}
