
import java.util.Random;

public class Tractor extends Thread {

    // Переменная хранящая экземпляр класса позволяющий генерировать случайные значения.
    private final Random rnd = new Random();

    // Переменная хранящая имя собственника потока.
    private final String name;

    // Переменные хранящие угол, коэффициент силы.
    private final int angle, coefPower;

    // Переменная хранящая экземпляр тележки.
    public static Cart cart;

    /**
     * Конструктор присваивающий полям значения.
     * @param name имя
     * @param angle угол
     * @param coefPower коэффициент силы
     * @param cart тележка
     */
    public Tractor(String name, int angle, int coefPower, Cart cart) {
        this.name = name;
        this.angle = angle;
        this.coefPower = coefPower;
        Tractor.cart = cart;
    }

    /*
    Метод исполнения потока.
     */
    @Override
    public void run() {
        // Цикл работающий до прерывание из вне.
        while (!isInterrupted()) {
            try {
                // Блок упорядочивающий доступ к общим ресурсам (телеге).
                synchronized (cart) {
                    System.out.println("The " + name + " started pulling cart");
                    // Записываем перемещение телеги.
                    cart.setX(cart.getX() + coefPower * Math.cos(angle));
                    cart.setY(cart.getY() + coefPower * Math.sin(angle));
                    System.out.println("The " + name + " tired and fall asleep");
                }
                Thread.sleep(rnd.nextInt(4000) + 1000);
            } catch (InterruptedException e) {
                System.out.println("The " + name + " has no power any more to take action!");
                interrupt();

            }

        }

    }
}
