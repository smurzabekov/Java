public class Movement {

    /**
     * Метод следящий за жизненым циклом, а ткаже выводящий каждые 2 секунды местоположение телеги
     * @param cart телега
     * @return успешно ли прошло время исполнения
     */
    public static boolean Timer(Cart cart) {
        // Задаес конец временного интервала жизненного цикла программы.
        long end = System.currentTimeMillis() + 25 * 1000;

        // Цикл следящий за временными рамки выполнения 25 секунд.
        // Также выводит каждые две секунды расположение тележки на координатной плоскости.
        while (System.currentTimeMillis() < end) {
            try {
                Thread.sleep(2000);
                System.out.println(cart);
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        try {
            // Чистим консоль.
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();

            // Присваиваем значения введенные из командной строки.
            Cart cart;
            if (args.length == 2) {
                cart = new Cart(Double.parseDouble(args[0]), Double.parseDouble(args[1]));
            } else if (args.length == 1) {
                cart = new Cart(Double.parseDouble(args[0]), Double.parseDouble(args[0]));
            } else cart = new Cart();

            // Создаем три тягачей.
            Tractor swan = new Tractor("Swan", 60, 1 + (int) (Math.random() * 9), cart);
            Tractor lobster = new Tractor("Lobster", 180, 1 + (int) (Math.random() * 9), cart);
            Tractor pike = new Tractor("Pike", 300, 1 + (int) (Math.random() * 9), cart);

            // Запускаем потоки.
            swan.start();
            lobster.start();
            pike.start();
            if (Timer(cart)) {
                // По истечению работы жизненого цикла программы прерываем потоки всех трех персонажей.
                swan.interrupt();
                lobster.interrupt();
                pike.interrupt();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}