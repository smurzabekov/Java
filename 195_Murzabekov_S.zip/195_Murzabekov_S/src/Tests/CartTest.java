import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CartTest {

    Cart cart = new Cart(5,5);
    @Test
    void getX() { ;
        assertEquals(cart.getX(), 5);
    }

    @Test
    void setX() {
        cart.setX(100);
        assertEquals(cart.getX(), 100);
    }

    @Test
    void getY() {
        assertEquals(cart.getY(), 5);
    }

    @Test
    void setY() {
        cart.setY(100);
        assertEquals(cart.getY(), 100);
    }

    @Test
    void testToString() {
        assertEquals(cart.toString(), "Cart is on [5,00, 5,00].");
    }
}