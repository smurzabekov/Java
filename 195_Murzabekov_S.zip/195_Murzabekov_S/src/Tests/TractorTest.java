import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TractorTest {

    @Test
    void run() {
        Cart cart = new Cart();
        Tractor oneOfThem = new Tractor("Tractor", 60, 5, cart);
        oneOfThem.start();
        oneOfThem.interrupt();
        assertEquals(cart.toString(), "Cart is on [0,00, 0,00].");
    }
}