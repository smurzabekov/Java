package Main;
import java.util.List;

public class BookingForm {
    private List<GuestForm> guests;
    private List<String> amenities;
    private String propertyType;
// геттеры / сеттеры опущены для краткости
}