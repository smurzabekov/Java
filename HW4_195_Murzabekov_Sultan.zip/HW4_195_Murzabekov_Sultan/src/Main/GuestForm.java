package Main;

public class GuestForm {
    private String firstName;
    private String lastName;
    private int age;
// геттеры / сеттеры опущены для краткости
}