package Main;


import Annotations.AnyOf;
import Annotations.Constrained;
import Annotations.NotNull;
import Annotations.Size;

import java.util.List;

@Constrained
public class BookingService {
    @NotNull
    @Size(min = 1, max = 5)
    private List<@NotNull GuestForm> guests;
    @NotNull
    private List<@AnyOf({"TV", "Kitchen"}) String> amenities;
    @NotNull
    @AnyOf({"House", "Hostel"})
    private String propertyType;
}
