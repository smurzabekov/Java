package Validation;

import Annotations.Constrained;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.text.MessageFormat;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class ConstrainedValidator implements Validator {
    private Map<Class<? extends Annotation>, FieldValidator> annotationsInCode;
    private Set<Class<? extends Annotation>> supportedFieldAnnotations;

    public ConstrainedValidator(Map<Class<? extends Annotation>, FieldValidator> annotationsInCode) {
        this.annotationsInCode = annotationsInCode;
        supportedFieldAnnotations = this.annotationsInCode.keySet();
    }

    @Override
    public Set<ValidationError> validate(Object checkingO) {

        Set<ValidationError> errors = new HashSet<ValidationError>();

        if (checkingO == null) {
            throw new ValidationException("there is some errors");
        }

        Class<?> objCl = checkingO.getClass();
        if (!objCl.isAnnotationPresent(Constrained.class)) {
            throw new ValidationException(objCl + "there are no any" + Constrained.class.getName() + "annotation.");
        }

        Field[] declaredFields = objCl.getDeclaredFields();
        for (int i =0;i<declaredFields.length;i++) {
            Field field = declaredFields[i];
            field.setAccessible(true);
            HashSet<ValidationError> errorFields = (HashSet<ValidationError>) supportedFieldAnnotations.stream()
                    .filter(field::isAnnotationPresent)
                    .map(annotationsInCode::get)
                    .map(filedValidator-> filedValidator.FieldValidate(checkingO, field))
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());
           errors.addAll(errorFields);
        }

        return errors;
    }
}
