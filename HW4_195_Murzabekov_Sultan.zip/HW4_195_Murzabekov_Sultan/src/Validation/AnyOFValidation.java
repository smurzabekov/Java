package Validation;

import java.lang.reflect.Field;
import java.util.Set;

public class AnyOFValidation implements FieldValidator {
    @Override
    public ValidationError FieldValidate(Object entity, Field field) {
        return null;
    }
}
