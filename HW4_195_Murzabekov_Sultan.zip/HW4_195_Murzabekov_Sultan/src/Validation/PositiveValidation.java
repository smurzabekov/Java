package Validation;

import Annotations.Positive;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Set;

public class PositiveValidation implements FieldValidator {
    @Override
    public ValidationError FieldValidate(Object obj, Field field) {

        if(long.class.equals(field.getGenericType())){
            Positive positive = (Annotation)field.getAnnotations(Positive.class);
            try {
                long fieldValue = (long) field.get(obj);
                if (fieldValue < 0) {

                    throw new ValidationException(field.getName() +" "+"path: "
                            + field.getClass().getCanonicalName() +  " field value: " + field.get(obj) + "is not positive")
                }
            } catch (IllegalAccessException e) {
                throw new ValidationException(e);
            }

                    }
        return null;
    }
}
