package GameParticipants;

public class Bot extends Player {

    /**
     * Конструктор проверябщий и присваивающий занчения полям:
     *
     * @param cash
     * @param opponent
     */
    public Bot(int cash, Player opponent) {
        super(cash, opponent);

    }

    /**
     * Метод принимающий от игрока ответа на вопрос
     *
     * @return ответ игрока
     */
    @Override
    public void displayInfo() {
        System.out.println("Bot has " + cash +
                "$ in the wallet, position: " + position +
                ", quontity of property: " + property.size() +
                ", debt: " + debt + "$."
        );
    }

    /**
     * Метод генерирующий ответ на вопрос.
     *
     * @return ответ игрока
     */
    @Override
    public String yesOrNo() {
        System.out.println("Enter Y or N");
        int rnd = (int) Math.random();
        if (rnd == 0) {
            System.out.println("Y");
            return "Y";
        } else {
            System.out.println("N");
            return "N";
        }

    }
}
