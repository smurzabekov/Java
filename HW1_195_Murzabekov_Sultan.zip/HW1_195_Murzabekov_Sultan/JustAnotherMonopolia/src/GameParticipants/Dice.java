package GameParticipants;

public class Dice {
    /**
     * Поле описывающее количество костей.
     */
    private static final int QUONTITY_DICE = 2;

    /**
     * Поле массив хранящий две кости.
     */
    private int[] dice = new int[QUONTITY_DICE];

    /**
     * Метод описывающий кидание костей.
     */
    public void roll() {
        for (int i = 0; i < QUONTITY_DICE; i++) {
            dice[i] = 1 + (int) (Math.random() * 6);
        }
    }

    /**
     * Метод выводящий сумму выпаной костями.
     *
     * @return суммы костей.
     */
    public int getDiceNumber() {
        this.roll();
        System.out.println("DICE: " + (dice[0] + dice[1]));
        return (dice[0] + dice[1]);
    }

}
