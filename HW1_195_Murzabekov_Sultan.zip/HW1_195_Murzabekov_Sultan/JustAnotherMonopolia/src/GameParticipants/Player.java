package GameParticipants;

import PartitionOfGameField.GameField;
import PartitionOfGameField.ShopCell;

import java.util.ArrayList;
import java.util.Scanner;

public class Player {

    /**
     * Поле указывающее на объем бюджета.
     */
    protected int cash;

    /**
     * Поле указывающее на текущую позицию на игровой арене.
     */
    protected int position = 1;

    /**
     * Поле указывающее на предыдущую позицию на игровой арене.
     */
    private int previousPosition = 1;

    /**
     * Поле указывающее на объем долга перед банком.
     */
    protected int debt;

    /**
     * Поле указывающее на материальное состояние игрока.
     */
    public boolean isBankrupt = false;

    /**
     * Список в котором хранится информация о имуществе игрока.
     */
    protected ArrayList<ShopCell> property = new ArrayList<ShopCell>();

    /**
     * Поле указывающее на сумму потраченную на развитие своего имущество.
     */
    private int spentOnImprovement;

    /**
     * Cвойство доступа к полю.
     *
     * @return потраченную на развитие своего имущество.
     */
    public int getSpentOnImprovement() {
        return spentOnImprovement;
    }

    /**
     * Cвойство доступа к полю.
     *
     * @return объем долга перед банком.
     */
    public int getDebt() {
        return debt;
    }

    /**
     * Метод закрытия долга перед банком.
     */
    public void debtRelief() {
        debt = 0;
    }

    /**
     * Cвойство доступа к полю.
     *
     * @return объем бюджета.
     */
    public int getBudget() {
        return cash;
    }

    /**
     * Конструктор проверябщий и присваивающий занчения полям:
     *
     * @param cash
     * @param opponent
     */
    public Player(int cash, Player opponent) {
        try {
            if (cash < 500 || cash > 15000) {
                throw new Exception("Format Exception. Please correct data");
            }
        } catch (Exception e) {
            e.getMessage();
        }
        this.cash = cash;
        displayInfo();
    }

    /**
     * Метод добавляющий к списку имущества новый магазин.
     *
     * @param shop
     */
    public void addShopToProperties(ShopCell shop) {
        property.add(shop);
    }

    /**
     * Метод вычитывающий потерю денег.
     *
     * @param loss
     */
    public void deductionCash(int loss) {
        if (cash > loss) {
            cash -= loss;
        } else {
            cash = 0;
            this.isBankrupt = true;
        }
    }

    /**
     * Метод осуществленияя добровольных трат.
     *
     * @param spendings
     * @return
     */
    public boolean spendingCash(int spendings) {
        if (cash > spendings) {
            cash -= spendings;
            spentOnImprovement += spendings;
            System.out.println("Operation has gone successfully!");
            return true;
        } else {
            System.out.println("You don't have enough money to buy it");
            return false;
        }
    }

    /**
     * Метод принимающий от игрока ответа на вопрос
     *
     * @return ответ игрока
     */
    public String yesOrNo() {
        System.out.println("Enter Y or N");
        Scanner sc = new Scanner(System.in);
        String answer;
        do {
            answer = sc.next();
        }
        while (answer == "Y" || answer == "N");
        return answer;
    }

    /**
     * Метод присваивающий кредитные деньги к бюджету.
     *
     * @param credit взятый кредит в банке.
     * @param debt   долг установленный банком.
     */
    public void getCredit(int credit, int debt) {
        cash += credit;
        this.debt += debt;
        System.out.println("You have taken credit for: " + credit + "$!");
        System.out.println("But you would have to pay off: " + debt + "$ the debt on the next hit on Bank!");
    }

    /**
     * Свойство доступа к полю.
     *
     * @return предыдущая позиция игрока на игровом поле.
     */
    public int getPreviousPosition() {
        return previousPosition;
    }

    /**
     * Свойство доступа к полю.
     *
     * @return позиция игрока на игровом поле.
     */
    public int getPosition() {
        return position;
    }

    /**
     * Метод присвоения компенсации при попадании опонента на имущетво игрока.
     *
     * @param income прибыли (компенсация)
     */
    public void getIncomeFromProperty(int income) {
        cash += income;
    }

    /**
     * Метод хода по игровому полю.
     *
     * @param step количесво пройденых клеток
     */
    public void move(int step) {
        previousPosition = position;
        position = position + step;

        if (position > GameField.QUONTITY_OF_CELLS) {
            position = position - GameField.QUONTITY_OF_CELLS;
        }
        if (position < 0) {
            position = position + GameField.QUONTITY_OF_CELLS;
        }

    }

    /**
     * Метод возвращающий информацию о параметрах игрока.
     */
    public void displayInfo() {
        System.out.println("You have " + cash +
                "$ in the wallet, position: " + position +
                ", quontity of property: " + property.size() +
                ", debt: " + debt + "$."
        );
    }
}
