package PartitionOfGameField;

import GameParticipants.Bot;
import GameParticipants.Player;

public class ShopCell extends EmptyCell {

    private int cost;
    private int compensation;
    public static double COMPENSATION_COEF;
    public static double IMPROVEMENT_COEF;
    private ShopProperty ownerType = ShopProperty.NOBODY;
    private Player owner;

    public ShopCell(){

        cost = 50 + (int)(Math.random() * ((500 - 50) + 1));
        compensation = (int)((0.5*cost) + (int)(Math.random() * (((0.9 * cost) - (0.5*cost)) + 1)));

    }
    @Override
    public void actions(Player player) {
        if (ownerType == ShopProperty.NOBODY) {
            buyThisShop(player);
        } else if (ownerType == ShopProperty.PLAYER) {
            if (player.getClass() == Player.class) {
               getUpgradeShopByPlayer(player);
            }
            if (player.getClass() == Bot.class) {
                getCompensationFromPlayer(player);
            }
        } else if (ownerType == ShopProperty.BOT) {
            if (player.getClass() == Bot.class) {
                getUpgradeShopByPlayer(player);
            }
            if (player.getClass() == Player.class) {
                getCompensationFromPlayer(player);
            }
        }

    }

    public void getCompensationFromPlayer(Player player) {
        System.out.println("You stopped on opponent's shop");
        System.out.println("From yours wallet will be removed " + compensation + "$");
        player.deductionCash(compensation);
        owner.getIncomeFromProperty(compensation);
    }

    /**
     * Метод для улучшения магазина
     * @param player
     */
    public void getUpgradeShopByPlayer(Player player) {
        System.out.println("Do you want to upgrade your shop for " + compensation + "$?");
        if (player.yesOrNo().equals("Y")) {
            if (!player.spendingCash(compensation)) {
                changeCost();
                return;
            }
        } else {
            System.out.println("OK! Please, keep playing");
        }
    }

    /**
     * метод для покупки магазина игроком
     * @param player
     */
    public void buyThisShop(Player player) {
        System.out.println("Do you what to buy this shop for " + cost + "$?");
        if (player.yesOrNo().equals("Y")) {
            if (!player.spendingCash(cost)) {
                return;
            }
            player.addShopToProperties(this);
            if (player.getClass() == Player.class) {
                ownerType = ShopProperty.PLAYER;
            } else {
                ownerType = ShopProperty.BOT;
            }
            owner = player;
        } else {
            System.out.println("OK! Please, keep playing");
        }
    }

    /**
     * изменение цены
     */
    public void changeCost() {
        cost = cost + (cost * (int) IMPROVEMENT_COEF);
        compensation = compensation + (compensation * (int) COMPENSATION_COEF);

    }

    /**
     * Ячейка поля из массива строки
     * @return
     */
    @Override
    protected String[] setCellOnConsole() {
        String[] shopCell = new String[]{
                "|─────────────| ",
                "|             | ",
                "|             | ",
                "|             | ",
                "|─────────────| ",
                "|     " + "Shop" + "    | ",
                "|─────────────| "};

        return this.visualAttendanceOnCell(shopCell);

    }
}
