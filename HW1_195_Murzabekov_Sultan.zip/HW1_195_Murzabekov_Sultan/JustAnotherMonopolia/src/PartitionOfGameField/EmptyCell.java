package PartitionOfGameField;

import GameParticipants.Player;

public class EmptyCell extends Cell {
    private boolean isPlayerHere = false;
    private boolean isBotHere = false;
    private int ID;

    /**
     * Свойство возвращающее ID игрока.
     *
     * @return
     */
    public int getID() {
        return this.ID;
    }

    /**
     * Метод проверяющий стоит ли игрок на этой клетке.
     *
     * @param player
     */
    public void onTheCell(Player player) {
        if (player.getPosition() == this.ID) {
            actions(player);
        }
    }

    /**
     * Свойство задающее ID игрока.
     *
     * @return
     */
    public void setID(int ID) {
        this.ID = ID;
    }

    /**
     * Свойство опредедяющее присутствие игрока на клетке.
     *
     * @param yesNo
     */
    protected void isPlayerHere(boolean yesNo) {
        isPlayerHere = yesNo;
    }

    /**
     * Свойство опредедяющее присутствие бота на клетке.
     *
     * @param yesNo
     */
    protected void isBotHere(boolean yesNo) {
        isBotHere = yesNo;
    }

    /**
     * Метод определяющий активность при попадании на клетку.
     *
     * @param player
     */
    @Override
    public void actions(Player player) {
        System.out.println(this.toString());
    }

    /**
     * Метод выводящий на на экран информацию о присутствии бота на клетке.
     *
     * @param cell
     * @return
     */
    @Override
    protected String[] visualAttendanceOnCell(String[] cell) {
        if (isPlayerHere && isBotHere) {
            cell[2] = "|     " + "Bot" + "     | ";
            cell[3] = "|" + "     Play    " + "| ";
            return cell;
        }
        if (isPlayerHere) {
            cell[3] = "|" + "     Play    " + "| ";
            return cell;
        }
        if (isBotHere) {
            cell[2] = "|     " + "Bot" + "     | ";
            return cell;
        }
        return cell;
    }

    /**
     * Метод генерирует визульную оболочку клетки для вывода.
     *
     * @return
     */
    @Override
    protected String[] setCellOnConsole() {
        String[] emptyCell = new String[]{
                "|─────────────| ",
                "|             | ",
                "|             | ",
                "|             | ",
                "|─────────────| ",
                "|    " + "Empty" + "    | ",
                "|─────────────| "};
        return this.visualAttendanceOnCell(emptyCell);
    }

    @Override
    public String toString() {
        return "Just relax there";
    }
}
