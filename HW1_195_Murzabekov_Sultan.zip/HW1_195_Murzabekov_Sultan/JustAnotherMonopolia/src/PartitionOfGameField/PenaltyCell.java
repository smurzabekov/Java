package PartitionOfGameField;

import GameParticipants.Player;

public class PenaltyCell extends EmptyCell {

    public static double PENALTY_COEF;

    public PenaltyCell() {

    }

    @Override
    public void actions(Player player) {
        int fine =(int)(player.getBudget() * PENALTY_COEF);
        System.out.println("You have stepped on Penalty Cell! You will be fined for " + fine + "$!");
        player.deductionCash(fine);
    }

    @Override
    protected String[] setCellOnConsole() {
        String[] penaltyCell = new String[]{
                "|─────────────| ",
                "|             | ",
                "|             | ",
                "|             | ",
                "|─────────────| ",
                "| " + "PenaltyCell" + " | ",
                "|─────────────| "};
        return this.visualAttendanceOnCell(penaltyCell);
    }
}
