package PartitionOfGameField;

import GameParticipants.Player;

public class BankCell extends EmptyCell {

    /**
     * Статическое поле определяющее коэффициент взятие кредита.
     */
    public static double CREDIT_COEF;

    /**
     * Статическое поля определяющее коэффиент долга перед банком
     */
    public static double DEBT_COEF;

    /**
     * Метод определяющий активности при попадании игрока на данную клетку.
     *
     * @param player
     */
    @Override
    public void actions(Player player) {
        System.out.println(player.getClass().getName() + " stopped on the Bank");
        if (player.getClass() == Player.class) {
            if (player.getDebt() <= 0) {
                System.out.println("Do you want to get credit?");
                if (player.yesOrNo().equals("Y")) {
                    takeCredit(player);
                } else {
                    System.out.println("OK! Please, continue the game!");
                }
            } else {
                System.out.println("The Bank obliges to pay your debt: " + player.getDebt() + "$!");
                System.out.println("This sum will be debited from your cash wallet!");
                player.deductionCash(player.getDebt());
                player.debtRelief();

            }
        } else {
            System.out.println("Bot can't take credit");
        }
    }

    /**
     * Метод определяющий взятие кредита в банке.
     *
     * @param player
     */
    private void takeCredit(Player player) {
        int credit = (int) (CREDIT_COEF * player.getSpentOnImprovement());
        int debt = (int) (DEBT_COEF * credit);
        player.getCredit(credit, debt);
    }

    /**
     * Метод опредляющий визуальную клетку.
     *
     * @return
     */
    @Override
    protected String[] setCellOnConsole() {
        String[] bankCell = new String[]{
                "|─────────────| ",
                "|             | ",
                "|             | ",
                "|             | ",
                "|─────────────| ",
                "|    " + "Bank" + "     | ",
                "|─────────────| "};
        return this.visualAttendanceOnCell(bankCell);
    }

}
