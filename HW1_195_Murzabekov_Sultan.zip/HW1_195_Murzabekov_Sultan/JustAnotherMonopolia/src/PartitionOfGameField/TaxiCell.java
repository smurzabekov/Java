package PartitionOfGameField;

import GameParticipants.Player;

import static MonopolyConsole.MonopolyGameProcess.FIELD;


public class TaxiCell extends EmptyCell {


    private int taxiDistance;

    public void setTaxiDistance(){
         taxiDistance = 3 + (int)(Math.random() * ((5 - 3) + 1));
    }
    @Override
    public void actions(Player player){
        setTaxiDistance();
        System.out.println("You stepped on Taxi! You will transported to " + taxiDistance + "!");
        player.move(taxiDistance);
        FIELD.resetPreviousPositionPlayer(player);
        //FIELD.SetAction(player);
    }
    @Override
    protected String[] setCellOnConsole() {
        String[] taxiCell = new String[]{
                "|─────────────| ",
                "|             | ",
                "|             | ",
                "|             | ",
                "|─────────────| ",
                "|    " + "Taxi" + "     | ",
                "|─────────────| "};
        return this.visualAttendanceOnCell(taxiCell);
    }
}
