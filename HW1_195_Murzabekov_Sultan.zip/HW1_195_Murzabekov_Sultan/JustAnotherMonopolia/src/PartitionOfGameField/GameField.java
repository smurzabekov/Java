package PartitionOfGameField;


import GameParticipants.Bot;
import GameParticipants.Player;

public final class GameField {

    /**
     * Статическое поле хранящее объекты клеток игрового поля.
     */
    private static EmptyCell[][] LINES;

    /**
     * Статическое поле хранящее количество клеток на игровом поле.
     */
    public static int QUONTITY_OF_CELLS;

    /**
     * Конструктор задающее параметры игрового поля.
     * @param width
     * @param height
     */
    public GameField(int width, int height) {
        try {
            if (width < 6 || width > 30 || height > 30 || height < 6) {
                throw new Exception("Format Exception. Please correct data");
            }
        } catch (Exception e) {
            e.getMessage();
        }
        generateGameFieldLines(width, height);

    }

    /**
     * Метод генерирующий игровое поле по типам клеток.
     * @param width
     * @param height
     */
    private void generateGameFieldLines(int width, int height) {

        LINES = new EmptyCell[][]{
                new EmptyCell[width],
                new EmptyCell[width],
                new EmptyCell[height],
                new EmptyCell[height]};
        LINES[0][0] = new EmptyCell();
        LINES[1][0] = new EmptyCell();
        LINES[0][width - 1] = new EmptyCell();
        LINES[1][width - 1] = new EmptyCell();
        for (int i = 0; i < 4; i++) {
            for (int count = 0; count < 2; count++) {
                LINES[i][random(i)] = new PenaltyCell();
                LINES[i][random(i)] = new TaxiCell();
            }
        }
        for (int i = 0; i < 4; i++) {
            LINES[i][random(i)] = new BankCell();
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 1; j < LINES[i].length - 1; j++) {
                if (LINES[i][j] == null) {
                    LINES[i][j] = new ShopCell();
                }
            }
        }
        idAssignment();
    }

    /**
     * Метод присваивающий каждой клетке идентификационный номер.
     */
    private void idAssignment() {
        int ID = 1;

        for (int j = 0; j < LINES[0].length; j++) {

            LINES[0][j].setID(ID);
            ID++;
            //System.out.println(ID);
        }


        for (int j = 1; j < LINES[3].length - 1; j++) {

            LINES[3][j].setID(ID);
            ID++;
            //System.out.println(ID);
        }

        for (int j = LINES[1].length - 1; j >= 0; j--) {

            LINES[1][j].setID(ID);
            ID++;
            //System.out.println(ID);
        }
        for (int j = LINES[2].length - 2; j > 0; j--) {

            LINES[2][j].setID(ID);
            ID++;
            //System.out.println(ID);
        }
        // System.out.println(ID);
        QUONTITY_OF_CELLS = ID - 1;
    }

    /**
     * Метод выводящий поле игры в консоль.
     * @param player
     * @param bot
     */
    public void showGameField(Player player, Player bot) {
        for (int count = 0; count < 7; count++, System.out.println()) {
            for (int i = 0; i < LINES[0].length; i++) {
                isPlayerOnThisCell(player, LINES[0][i]);
                isPlayerOnThisCell(bot, LINES[0][i]);
                System.out.printf(LINES[0][i].setCellOnConsole()[count]);
            }

        }
        for (int j = 1, i = 1; j < LINES[3].length - 1 && i < LINES[2].length - 1; j++, i++) {
            for (int count = 0; count < 7; count++, System.out.println()) {
                isPlayerOnThisCell(player, LINES[2][i]);
                isPlayerOnThisCell(bot, LINES[2][j]);
                isPlayerOnThisCell(player, LINES[3][i]);
                isPlayerOnThisCell(bot, LINES[3][j]);

                System.out.print(LINES[2][i].setCellOnConsole()[count] +
                        repeat(LINES[0].length - 2) +
                        LINES[3][i].setCellOnConsole()[count]);

            }
        }
        for (int count = 0; count < 7; count++, System.out.println()) {
            for (int i = 0; i < LINES[1].length; i++) {
                isPlayerOnThisCell(player, LINES[1][i]);
                isPlayerOnThisCell(bot, LINES[1][i]);
                System.out.printf(LINES[1][i].setCellOnConsole()[count]);
            }
        }
    }

    /**
     * Метод проверяющий приссутствие
     * @param player
     * @param cell
     */
    private void isPlayerOnThisCell(Player player, EmptyCell cell) {
        //System.out.print(player.GetPosition());
        if (player.getPosition() == cell.getID()) {
            if (player.getClass() == Bot.class) {
                cell.isBotHere(true);
            }
            if (player.getClass() == Player.class) {
                cell.isPlayerHere(true);
            }
        }
    }

    /**
     * Метод генерирует рандомное число в пределах рамера поля.
     * @param index
     * @return
     */
    private int random(int index) {
        return (int) ((Math.random() * ((LINES[index].length - 1) - 1)) + 1);
    }

    /**
     * Метод убирающий визуальное присутствие игрока на предыдущей позиции на поле
     * @param player
     */
    public void resetPreviousPositionPlayer(Player player) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < LINES[i].length; j++) {
                checkingReset(player, LINES[i][j]);
            }
        }
        for (int i = 2; i < 4; i++) {
            for (int j = 1; j < LINES[i].length - 1; j++) {
                checkingReset(player, LINES[i][j]);
            }
        }
    }

    /**
     * Метод проверки присутсвия.
     * @param player
     * @param cell
     */
    private void checkingReset(Player player, EmptyCell cell) {
        if (player.getPreviousPosition() == cell.getID()) {
            if (player.getClass() == Bot.class) {
                cell.isBotHere(false);
            }
            if (player.getClass() == Player.class) {
                cell.isPlayerHere(false);
            }
        }
    }

    /**
     * Метод повтора пустой строки
     * @param count
     * @param with
     * @return
     */
    private String repeat(int count, String with) {
        return new String(new char[count]).replace("\0", with);
    }

    /**
     * Метод повтора пустой строки
     * @param count
     * @return
     */
    private String repeat(int count) {
        return repeat(count, "                ");
    }

    /**
     * Метод устанавливает действие на
     * @param player
     */
    public void setAction(Player player) {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < LINES[i].length; j++) {
                LINES[i][j].onTheCell(player);
            }
        }
        for (int i = 2; i < 4; i++) {
            for (int j = 1; j < LINES[i].length - 1; j++) {
                LINES[i][j].onTheCell(player);
            }
        }
    }
}
