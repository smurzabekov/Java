package PartitionOfGameField;

public enum ShopProperty {
    NOBODY,
    BOT,
    PLAYER
}
