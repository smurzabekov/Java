package PartitionOfGameField;

import GameParticipants.Player;

abstract class Cell {

    /**
     * Свойство возвращающее ID игрока.
     *
     * @return
     */
    public abstract int getID();


    /**
     * Свойство задающее ID игрока.
     *
     * @return
     */
    public abstract void setID(int ID);

    /**
     * Свойство опредедяющее присутствие игрока на клетке.
     *
     * @param yesNo
     */
    abstract void isPlayerHere(boolean yesNo);

    /**
     * Свойство опредедяющее присутствие бота на клетке.
     *
     * @param yesNo
     */
    abstract void isBotHere(boolean yesNo);

    /**
     * Метод выводящий на на экран информацию о присутствии бота на клетке.
     *
     * @param cell
     * @return
     */
    abstract String[] visualAttendanceOnCell(String[] cell);

    /**
     * Метод генерирует визульную оболочку клетки для вывода.
     *
     * @return
     */
    abstract String[] setCellOnConsole();

    /**
     * Метод определяющий активность при попадании на клетку.
     *
     * @param player
     */
    public abstract void actions(Player player);
}
