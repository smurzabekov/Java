package MonopolyConsole;

import GameParticipants.Player;

import java.util.Scanner;


public class Main {

    public static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

//        args = new String[3];
//        args[0] = "6";
//        args[1] = "6";
//        args[2] = "1000";

        if (args.length != 3) {
            System.out.println("INCORRECT INPUT DATA!!!!!!!!!!!!!!!!!!");
            return;
        }
        MonopolyGameProcess monopoly;
        try{
            monopoly = new MonopolyGameProcess(args);
        }
        catch (Exception e){
            System.out.println("incorrect INPUT!");
            return;
        }

        Player player = monopoly.decideFirstStep();
        System.out.println("Press Enter to continue the game!");
        sc.nextLine();
        System.out.println("**************************************************************************");
        do {
            monopoly.gameProcess(player);
            if (!monopoly.gameOver()) {
                player = monopoly.changeTurn(player);
            }

            System.out.println("Press Enter to continue the game!");
            sc.nextLine();
            System.out.println("**************************************************************************");

        } while (!monopoly.gameOver());
        monopoly.whoWin();
    }
}
