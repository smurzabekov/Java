package MonopolyConsole;

import GameParticipants.Bot;
import GameParticipants.Dice;
import GameParticipants.Player;
import PartitionOfGameField.BankCell;
import PartitionOfGameField.GameField;
import PartitionOfGameField.PenaltyCell;

import java.util.Random;

public class MonopolyGameProcess {

    /**
     * Статическое поле определяющее игрока.
     */
    public static Player PLAYER;

    /**
     * Статическое поле определяющее бота.
     */
    public static Bot BOT;

    /**
     * Статическое поле определяющее поле игры.
     */
    public static GameField FIELD;

    /**
     * Статическое поле определяющее игровые кости.
     */
    public static Dice DICE = new Dice();

    /**
     * Статическое поле определяющее рандомный класс.
     */
    public static final Random rnd = new Random();

    /**
     * Метод задающий игрока первого начинающего игру.
     *
     * @return игрока производящего ход первым.
     */
    public Player decideFirstStep() {
        int i = (int) (Math.random() * 1);
        if (i == 0) {
            return BOT;
        } else {
            return PLAYER;
        }
    }

    /**
     * Метод проверяющий живность игроков
     *
     * @return булевое значение
     */
    public boolean gameOver() {
        if (BOT.isBankrupt || PLAYER.isBankrupt) {
            return true;
        }
        return false;
    }

    /**
     * Метод передающий ход между игроками.
     *
     * @param player игрок прошедший ход.
     * @return
     */
    public Player changeTurn(Player player) {
        if (player.getClass() == Player.class) {
            System.out.println("Now there is BOT'S turn");
            return BOT;
        } else {
            System.out.println("Now there is PLAYER'S turn");
            return PLAYER;
        }
    }

    /**
     * Конструктор создающий игроков учваствующих в игре, генерирует поле игры и коэффициенты.
     *
     * @param args параметры заданные игроком: размер поля и начальный размер бюджета.
     */
    public MonopolyGameProcess(String[] args) {
            PenaltyCell.PENALTY_COEF = (1 + rnd.nextInt(10)) / 100.0;
            BankCell.DEBT_COEF = (100 + rnd.nextInt(201)) / 100.0;
            BankCell.CREDIT_COEF = (2 + rnd.nextInt(199)) / 1000.0;
            System.out.println("Penalty coefficent is: " + PenaltyCell.PENALTY_COEF);
            System.out.println("Credit coefficent is: " + BankCell.CREDIT_COEF);
            System.out.println("Debt coefficent is: " + BankCell.DEBT_COEF);
            System.out.println("_________________________________________________________________________");

            FIELD = new GameField(Integer.parseInt(args[1]), Integer.parseInt(args[0]));
            PLAYER = new Player(Integer.parseInt(args[2]), BOT);
            BOT = new Bot(Integer.parseInt(args[2]), PLAYER);
            FIELD.showGameField(PLAYER, BOT);
            System.out.println("The game has started!");
    }

    /**
     * Метод описывающий ход игрока.
     *
     * @param player игрок производящий ход.
     */
    public static void gameProcess(Player player) {
        player.move(DICE.getDiceNumber());
        FIELD.resetPreviousPositionPlayer(player);
        FIELD.showGameField(PLAYER, BOT);
        FIELD.setAction(player);
        player.displayInfo();
    }

    /**
     * Метод подводящий итоги игры.
     */
    public static void whoWin() {
        if (PLAYER.isBankrupt) {
            System.out.println("BOT WIN!!!");
        }
        if (BOT.isBankrupt) {
            System.out.println("YOU WIN!!!");
        }
    }
}
