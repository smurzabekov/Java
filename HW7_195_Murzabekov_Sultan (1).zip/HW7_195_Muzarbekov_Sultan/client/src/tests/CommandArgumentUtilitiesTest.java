import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommandArgumentUtilitiesTest {

    @Test
    void getPortFromArguments() {
        var args = new String[] {"-port", "81", "-host", "localhost"};

        var port = CommandArgumentUtilities.getPortFromArguments(args);
        Assertions.assertEquals(81, port);
    }

    @Test
    void incorrectPortFromArguments() {
        var args = new String[] {"-port", "abracadabra", "-host", "localhost"};

        Assertions.assertThrows(NumberFormatException.class,
                () -> CommandArgumentUtilities.getPortFromArguments(args));
    }

    @Test
    void noNeededArgumentsTest() {
        var args = new String[0];

        Assertions.assertThrows(IllegalArgumentException.class,
                () -> CommandArgumentUtilities.getPortFromArguments(args));

        Assertions.assertThrows(IllegalArgumentException.class,
                () -> CommandArgumentUtilities.getHostFromArguments(args));
    }

    @Test
    void getHostFromArguments() {
        var args = new String[] {"-port", "81", "-host", "localhost"};

        var host = CommandArgumentUtilities.getHostFromArguments(args);
        Assertions.assertEquals("localhost", host);
    }
}