import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.Scanner;

class TorrentManagerTest {

    private static final String textFromFile = "text for test";
    private static final String pathToSaveFile = "src/output";

    private TorrentManager torrentManager;

    private ByteArrayOutputStream byteArrayOutputStream;

    @BeforeEach
    void setUp() {
        byteArrayOutputStream = new ByteArrayOutputStream(2048);
        var dataOutputStream = new DataOutputStream(byteArrayOutputStream);

        byte[] inputBuffer = textFromFile.getBytes();
        var byteInputStream = new ByteArrayInputStream(inputBuffer);
        var dataInputStream = new DataInputStream(byteInputStream);

        var scanner = new Scanner(System.in);

        torrentManager = new TorrentManager(dataInputStream, dataOutputStream, scanner);
    }

    @Test
    void executeListCommand() {
        try {
            torrentManager.executeListCommand();
        } catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        Assertions.assertTrue(checkOutputStreamContain(Main.listCommand));
    }

    @Test
    void executeExitCommand() throws IOException {
        torrentManager.executeExitCommand();

        Assertions.assertTrue(checkOutputStreamContain(Main.exitCommand));
    }

    @Test
    void receiveFile() throws IOException {
        torrentManager.receiveFile(pathToSaveFile, textFromFile.length());

        try(var fileReader = new FileInputStream(pathToSaveFile)) {
            var result = new String(fileReader.readAllBytes());
            Assertions.assertEquals(textFromFile, result);
        }
    }

    private boolean checkOutputStreamContain(String content) {
        return byteArrayOutputStream.toString().contains(content);
    }
}