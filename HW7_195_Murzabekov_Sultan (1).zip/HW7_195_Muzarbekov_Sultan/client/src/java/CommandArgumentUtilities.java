public class CommandArgumentUtilities {
    static final String hostArgumentName = "-host";
    static final String portArgumentName = "-port";

    /**
     * Parse command line arguments and find host argument
     * @param args command line arguments
     * @return passed host argument
     */
    public static String getHostFromArguments(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals(hostArgumentName)) {
                return args[i + 1];
            }
        }
        throw new IllegalArgumentException("Cannot find host argument, please define with -host flag");
    }

    /**
     * Parse command line arguments and find port argument
     * @param args command line arguments
     * @return passed port argument
     */
    public static int getPortFromArguments(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals(portArgumentName)) {
                return Integer.parseInt(args[i + 1]);
            }
        }
        throw new IllegalArgumentException("Cannot find host argument, please define with -port flag");
    }
}
