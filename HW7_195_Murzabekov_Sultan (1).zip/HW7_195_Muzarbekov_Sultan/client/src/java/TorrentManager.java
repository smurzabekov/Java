import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

class TorrentManager {
    private static final int MAX_SIZE = 2048;
    private static final String confirmCommand = "confirm";
    private static final String fileIsTooBigResponse = "File is too big for sending.";

    private final DataInputStream inputStream;
    private final DataOutputStream outputStream;
    private final Scanner scanner;

    TorrentManager(DataInputStream inputStream,
                   DataOutputStream outputStream,
                   Scanner scanner) {
        this.inputStream = inputStream;
        this.outputStream = outputStream;
        this.scanner = scanner;
    }

    /**
     * Send to server "list" command -- read list of files for sharing.
     * @throws IOException Throws with connectivity problems.
     */
    void executeListCommand() throws IOException {
        outputStream.writeUTF(Main.listCommand);
        System.out.println(inputStream.readUTF());
    }

    /**
     * Send to server "download" command -- command for download file from client
     * @param request client request specific by format "download n" where n is position of file in file list.
     * @throws IOException Throws with connectivity problems.
     */
    void executeDownloadCommand(String request) throws IOException {
        if (!validateDownloadRequest(request)) {
            System.out.println("Incorrect command");
            return;
        }
        outputStream.writeUTF(request);
        var response = inputStream.readUTF();
        if (response.equals(fileIsTooBigResponse)) {
            System.out.println(fileIsTooBigResponse);
            return;
        }
        System.out.println(response);
        var confirm = scanner.nextLine();
        if (confirm.equals(confirmCommand)) {
            outputStream.writeUTF(confirm);
            System.out.println("Enter path for save...");
            var pathToSaveFile = scanner.nextLine();
            var fileSize = inputStream.readLong();
            receiveFile(pathToSaveFile, fileSize);
        }
    }

    private boolean validateDownloadRequest(String request) {
        if (request.split(" ").length != 2) {
            throw new IllegalStateException("Wrong input command. Please specify number");
        }
        var position = request.split(" ")[1];
        try {
            Integer.parseInt(position);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    void executeExitCommand() throws IOException {
        outputStream.writeUTF(Main.exitCommand);
    }

    /**
     * Receive file from input stream of server.
     * @param pathToSaveFile path to file where will be content saved.
     * @param fileSize size of receiving file
     * @throws IOException Throws with connectivity problems or with file system problem.
     */
    public void receiveFile(String pathToSaveFile, long fileSize) throws IOException {
        long loaded = 0;
        Set<Long> percents = new HashSet<>();
        try (var fileStream = new FileOutputStream(pathToSaveFile)) {
            var receivedBytes = 0;
            while (receivedBytes < fileSize) {
                byte[] data;
                if (fileSize - receivedBytes >= MAX_SIZE) {
                    data = new byte[MAX_SIZE];
                    loaded += MAX_SIZE;
                } else {
                    var size = (int)(fileSize - receivedBytes);
                    data = new byte[size];
                    loaded += size;
                }
                long percent = (long)(loaded * 1. / fileSize * 100);
                if (percent % 10 == 0) {
                    if (!percents.contains(percent)) {
                        System.out.println("Percent of loaded: " + percent + "%");
                        percents.add(percent);
                    }
                }
                receivedBytes += inputStream.read(data);
                fileStream.write(data);
            }
        }

        System.out.println("\nDownload completed.");
    }
}
