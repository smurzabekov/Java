import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Main {
    static final String listCommand = "list";
    private static final String downloadCommand = "download";
    static final String exitCommand = "exit";

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);

        String host;
        int port;
        try {
            host = CommandArgumentUtilities.getHostFromArguments(args);
            port = CommandArgumentUtilities.getPortFromArguments(args);
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
            return;
        }

        try (Socket clientSocket = new Socket(host, port);
             DataInputStream inputStream = new DataInputStream(clientSocket.getInputStream());
             DataOutputStream outputStream = new DataOutputStream(clientSocket.getOutputStream())) {

            var torrentManager = new TorrentManager(inputStream, outputStream, scanner);
            System.out.println(inputStream.readUTF());

            printHelpText();

            String request;
            while (!(request = scanner.nextLine()).equals(exitCommand)) {
                try {
                    if (request.startsWith(downloadCommand)) {
                        executeDownloadCommand(torrentManager, request);
                    }
                    if (request.startsWith(listCommand)) {
                        executeListCommand(torrentManager);
                    }
                } catch (IllegalStateException ex) {
                    System.out.println(ex.getMessage());
                }
                printHelpText();
            }

            torrentManager.executeExitCommand();
            System.out.println("Exit from torrent.");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private static void executeListCommand(TorrentManager torrentManager) {
        try {
            torrentManager.executeListCommand();
        } catch (IOException exception) {
            System.out.println(exception.getMessage());
            System.out.println("Try again.");
        }
    }

    private static void executeDownloadCommand(TorrentManager torrentManager, String request) {
        try {
            torrentManager.executeDownloadCommand(request);
        } catch (IOException exception) {
            System.out.println(exception.getMessage());
            System.out.println("Try again.");
        }
    }

    private static void printHelpText() {
        System.out.println("Available command:\n" +
                "download n\t download file from position n\n" +
                "list\t list files for sharing\n" +
                "exit\t exit from client\n");
    }
}
