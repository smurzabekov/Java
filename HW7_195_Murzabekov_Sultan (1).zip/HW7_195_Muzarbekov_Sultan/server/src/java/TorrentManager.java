import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

class TorrentManager {
    private static final int PORTION_MAX_SIZE = 2048;
    private static final long MAX_FILE_SIZE = 128 * 1024 * 1024 * 8;
    private static final String confirmCommand = "confirm";
    private static final String declineCommand = "decline";

    private final DataInputStream inputStream;
    private final DataOutputStream outputStream;
    private final FileManager fileManager;

    TorrentManager(DataInputStream inputStream,
                   DataOutputStream outputStream,
                   FileManager fileManager) {
        this.inputStream = inputStream;
        this.outputStream = outputStream;
        this.fileManager = fileManager;
    }

    /**
     * Send to client response for "list" command -- list of files.
     * @throws IOException Throws with connectivity problems.
     */
    void executeListCommand() throws IOException {
        outputStream.writeUTF("List of file for sharing:\n" + convertToString(fileManager.getListOfFiles()));
    }

    /**
     * Send to client response for "download" command -- file content.
     * @param filePosition spesific position file for sharing.
     * @throws IOException Throws with connectivity problems.
     */
    void executeDownloadCommand(int filePosition) throws IOException {
        var fileInfo = fileManager.getFileByPosition(filePosition);
        if (fileInfo.getSize() > MAX_FILE_SIZE) {
            outputStream.writeUTF("File is too big for sending.");
        }
        String verdict;
        do {
            outputStream.writeUTF("File choose for download:\n" + fileInfo + "\nSend \"confirm\" or \"decline\" to continue.");
        } while (!(verdict = inputStream.readUTF()).equals(confirmCommand) && !verdict.equals(declineCommand));

        if (verdict.equals(confirmCommand)) {
            outputStream.writeLong(fileInfo.getSize());
            sendFile(fileInfo);
        }
    }

    private static String convertToString(List<FileInfo> fileInfoList) {
        var listAsString = new StringBuilder();
        for (int i = 0; i < fileInfoList.size(); i++) {
            addFileInfoToList(listAsString, i, fileInfoList.get(i));
        }
        return listAsString.toString();
    }

    private static void addFileInfoToList(StringBuilder stringBuilder, int position, FileInfo fileInfo) {
        stringBuilder.append(position).append(") ").append(fileInfo).append("\n");
    }

    /**
     * Send file to client.
     * @param file FileInfo about sharing file.
     * @throws IOException Throws with connectivity problems.
     */
    public void sendFile(FileInfo file) throws IOException {
        try (var stream = new FileInputStream(file.getName())) {
            var sendBytes = 0;
            while (sendBytes < file.getSize()) {
                byte[] fileAsBytes;
                if (file.getSize() - sendBytes >= PORTION_MAX_SIZE) {
                    fileAsBytes = new byte[PORTION_MAX_SIZE];
                } else {
                    fileAsBytes = new byte[(int) (file.getSize() - sendBytes)];
                }

                sendBytes += stream.read(fileAsBytes);
                outputStream.write(fileAsBytes);
            }
        }
    }
}
