import java.io.Serializable;

/**
 * Present info about file such that absolute file name and file size.
 */
public class FileInfo implements Serializable {
    private final String name;
    private final long size;

    FileInfo(String name, long size)
    {
        this.name = name;
        this.size = size;
    }

    String getName() {
        return name;
    }

    long getSize() {
        return size;
    }

    @Override
    public String toString() {
        return "file name: " + name + "\t\t" + "size: " + size;
    }
}
