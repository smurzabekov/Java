import java.io.File;
import java.util.ArrayList;
import java.util.List;

class FileManager {
    private final File[] files;

    FileManager(String pathToDirectory) {
        files = new File(pathToDirectory).listFiles();
    }

    /**
     * Get FileInfo list by files from directory.
     * @return list of FileInfo.
     */
    List<FileInfo> getListOfFiles() {
        var listOfFiles = new ArrayList<FileInfo>();

        for (var file : files) {
            listOfFiles.add(new FileInfo(file.getName(), file.length()));
        }
        return listOfFiles;
    }

    /**
     * Get FileInfo by file from specific position
     * @param position position in files list.
     * @return FileInfo about specific file.
     */
    FileInfo getFileByPosition(int position) {
        var file = files[position];
        return new FileInfo(file.getAbsolutePath(), file.length());
    }
}
