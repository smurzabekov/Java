import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;

public class Main {
    private static final String exitCommand = "exit";
    private static final String pathOption = "-path";
    private static final String listCommand = "list";
    private static final String downloadCommand = "download";
    private static final int port = 81;

    public static void main(String[] args) {
        String pathToFile;
        try {
            pathToFile = parseArguments(args);
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
            return;
        }
        var fileManager = new FileManager(pathToFile);

        try (var serverSocket = new ServerSocket(port);
             var clientSocket = serverSocket.accept();
             var inputStream = new DataInputStream(clientSocket.getInputStream());
             var outputStream = new DataOutputStream(clientSocket.getOutputStream())) {

            var torrentManager = new TorrentManager(inputStream, outputStream, fileManager);
            torrentManager.executeListCommand();

            String clientCommand;
            while (!(clientCommand = inputStream.readUTF()).isEmpty()) {
                if (clientCommand.startsWith(listCommand)) {
                    executeListCommand(torrentManager);
                }
                if (clientCommand.startsWith(downloadCommand)) {
                    var filePosition = tryParse(clientCommand.split(" ")[1]);
                    if (filePosition < 0) {
                        System.out.println("Incorrect file position.");
                        continue;
                    }
                    executeDownloadCommand(torrentManager, filePosition);
                }
                if (clientCommand.startsWith(exitCommand)) {
                    System.out.println("Close torrent.");
                    break;
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }

    private static int tryParse(String integer) {
        try {
            return Integer.parseInt(integer);
        } catch (Exception ex) {
            return -1;
        }
    }

    private static void executeListCommand(TorrentManager torrentManager) {
        try {
            torrentManager.executeListCommand();
        } catch (IOException exception) {
            System.out.println(exception.getMessage());
            System.out.println("Try again.");
        }
    }

    private static void executeDownloadCommand(TorrentManager torrentManager, int filePosition) {
        try {
            torrentManager.executeDownloadCommand(filePosition);
        } catch (IOException exception) {
            System.out.println(exception.getMessage());
            System.out.println("Try again.");
        }
    }

    private static String parseArguments(String[] args) {
        if (args.length != 2 || !args[0].equals(pathOption)) {
            printHelpText();
            throw new IllegalArgumentException("Incorrect startup arguments. Path to directory is not defined.");
        }

        return args[1];
    }

    private static void printHelpText() {
        System.out.println("Options for start:");
        System.out.print(pathOption);
        System.out.println("\t path to directory with files for sharing.");
    }
}
