import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtilities {
    public static final String directoryPath = "src\\resources";
    public static final String textForFile = "hello everyone";
    public static final String fileNameTemplate = "test";

    public static void createFilesForTest() throws IOException {
        var directory = new File(directoryPath);
        directory.mkdir();
        if (directory.listFiles() != null) {
            for (var file : directory.listFiles()) {
                file.delete();
            }
        }
        for (int i = 0; i < 5; i++) {
            try (var fileWriter = new FileWriter(getFileName(i, directoryPath))) {
                fileWriter.write(textForFile);
            }
        }
    }

    public static String getFileName(int position, String directoryPath) {
        return directoryPath + "/" + fileNameTemplate + position;
    }
}
