import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class TorrentManagerTest {

    private TorrentManager torrentManager;
    private FileManager fileManager;

    private ByteArrayOutputStream byteArrayOutputStream;

    @BeforeEach
    void setUp() throws IOException {
        FileUtilities.createFilesForTest();
        fileManager = new FileManager(FileUtilities.directoryPath);

        byteArrayOutputStream = new ByteArrayOutputStream(2048);
        var dataOutputStream = new DataOutputStream(byteArrayOutputStream);

        byte[] inputBuffer = new byte[2048];
        var byteInputStream = new ByteArrayInputStream(inputBuffer);
        var dataInputStream = new DataInputStream(byteInputStream);

        torrentManager = new TorrentManager(dataInputStream, dataOutputStream, fileManager);
    }

    @Test
    public void executeListCommand() throws IOException {
        var expectedResponse = "List of file for sharing:\n" + convertToString(fileManager.getListOfFiles());

        torrentManager.executeListCommand();

        Assertions.assertTrue(checkOutputStreamContain(expectedResponse));
    }

    @Test
    public void sendFile() throws IOException {
        var expectedResponse = FileUtilities.textForFile;

        var file = fileManager.getFileByPosition(0);
        torrentManager.sendFile(file);

        Assertions.assertTrue(checkOutputStreamContain(expectedResponse));
    }

    private boolean checkOutputStreamContain(String content) {
        return byteArrayOutputStream.toString().contains(content);
    }

    private static String convertToString(List<FileInfo> fileInfoList) {
        var listAsString = new StringBuilder();
        for (int i = 0; i < fileInfoList.size(); i++) {
            addFileInfoToList(listAsString, i, fileInfoList.get(i));
        }
        return listAsString.toString();
    }

    private static void addFileInfoToList(StringBuilder stringBuilder, int position, FileInfo fileInfo) {
        stringBuilder.append(position).append(") ").append(fileInfo).append("\n");
    }
}