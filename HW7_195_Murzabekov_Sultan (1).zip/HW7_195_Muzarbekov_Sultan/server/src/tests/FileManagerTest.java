import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.nio.file.Paths;

class FileManagerTest {
    private FileManager fileManager;

    @BeforeEach
    void setUp() throws IOException {
        FileUtilities.createFilesForTest();
        fileManager = new FileManager(FileUtilities.directoryPath);
    }

    @Test
    void getListOfFiles() {
        var listOfFiles = fileManager.getListOfFiles();
        for (int i = 0; i < listOfFiles.size(); i++) {
            Assertions.assertEquals(FileUtilities.fileNameTemplate + i, listOfFiles.get(i).getName());
            Assertions.assertEquals(FileUtilities.textForFile.getBytes().length, listOfFiles.get(i).getSize());
        }
    }

    @Test
    void getFileByPosition() {
        var fileByPosition = fileManager.getFileByPosition(0);
        Assertions.assertEquals(Paths.get("").toAbsolutePath() + "\\" + FileUtilities.directoryPath + "\\" + FileUtilities.fileNameTemplate + "0", fileByPosition.getName());
        Assertions.assertEquals(FileUtilities.textForFile.getBytes().length, fileByPosition.getSize());
    }
}